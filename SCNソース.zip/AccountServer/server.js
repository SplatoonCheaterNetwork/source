"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const morgan_1 = __importDefault(require("morgan"));
const xmlbuilder_1 = __importDefault(require("xmlbuilder"));
const xml_parser_1 = __importDefault(require("./middleware/xml-parser"));
const cache_1 = require("./cache");
const database_1 = require("./database");
const server_1 = require("./services/grpc/server");
const util_1 = require("./util");
const logger_1 = require("./logger");
const conntest_1 = __importDefault(require("./services/conntest"));
const cbvc_1 = __importDefault(require("./services/cbvc"));
const nnas_1 = __importDefault(require("./services/nnas"));
const nasc_1 = __importDefault(require("./services/nasc"));
const datastore_1 = __importDefault(require("./services/datastore"));
const api_1 = __importDefault(require("./services/api"));
const local_cdn_1 = __importDefault(require("./services/local-cdn"));
const assets_1 = __importDefault(require("./services/assets"));
const config_manager_1 = require("./config-manager");
process.title = 'Pretendo - Account';
process.on('uncaughtException', (err, origin) => {
    console.log(err);
    console.log(origin);
});
process.on('SIGTERM', () => {
    process.exit(0);
});
const app = (0, express_1.default)();
// * START APPLICATION
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
// * Create router
(0, logger_1.LOG_INFO)('Setting up Middleware');
app.use((0, morgan_1.default)('dev'));
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({
    extended: true
}));
app.use(xml_parser_1.default);
// * import the servers into one
app.use(conntest_1.default);
app.use(cbvc_1.default);
app.use(nnas_1.default);
app.use(nasc_1.default);
app.use(api_1.default);
app.use(local_cdn_1.default);
app.use(assets_1.default);
if (!config_manager_1.disabledFeatures.datastore) {
    app.use(datastore_1.default);
}
// * 404 handler
(0, logger_1.LOG_INFO)('Creating 404 status handler');
app.use((request, response) => {
    const url = (0, util_1.fullUrl)(request);
    let deviceID = (0, util_1.getValueFromHeaders)(request.headers, 'X-Nintendo-Device-ID');
    if (!deviceID) {
        deviceID = 'Unknown';
    }
    (0, logger_1.LOG_WARN)(`HTTP 404 at ${url} from ${deviceID}`);
    response.set('Content-Type', 'text/xml');
    response.set('Server', 'Nintendo 3DS (http)');
    response.set('X-Nintendo-Date', new Date().getTime().toString());
    response.status(404).send(xmlbuilder_1.default.create({
        errors: {
            error: {
                cause: '',
                code: '0008',
                message: 'Not Found'
            }
        }
    }).end());
});
// * non-404 error handler
(0, logger_1.LOG_INFO)('Creating non-404 status handler');
app.use((error, request, response, _next) => {
    const status = error.status || 500;
    const url = (0, util_1.fullUrl)(request);
    let deviceID = (0, util_1.getValueFromHeaders)(request.headers, 'X-Nintendo-Device-ID');
    if (!deviceID) {
        deviceID = 'Unknown';
    }
    (0, logger_1.LOG_WARN)(`HTTP ${status} at ${url} from ${deviceID}: ${error.message}`);
    response.status(status).json({
        app: 'api',
        status,
        error: error.message
    });
});
async function main() {
    // * Starts the server
    (0, logger_1.LOG_INFO)('Starting server');
    await (0, database_1.connect)();
    (0, logger_1.LOG_SUCCESS)('Database connected');
    await (0, cache_1.connect)();
    (0, logger_1.LOG_SUCCESS)('Cache enabled');
    await (0, server_1.startGRPCServer)();
    (0, logger_1.LOG_SUCCESS)(`gRPC server started on port ${config_manager_1.config.grpc.port}`);
    app.listen(config_manager_1.config.http.port, () => {
        (0, logger_1.LOG_SUCCESS)(`HTTP server started on port ${config_manager_1.config.http.port}`);
    });
}
main().catch(console.error);
