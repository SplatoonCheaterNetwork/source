"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.removePNIDConnectionDiscord = exports.removePNIDConnection = exports.addPNIDConnectionDiscord = exports.addPNIDConnection = exports.getServerByClientID = exports.getServerByTitleID = exports.getServerByGameServerID = exports.getPNIDProfileJSONByPID = exports.getPNIDByAPIRefreshToken = exports.getPNIDByAPIAccessToken = exports.getPNIDByNNASRefreshToken = exports.getPNIDByNNASAccessToken = exports.getPNIDByBasicAuth = exports.doesPNIDExist = exports.getPNIDByEmailAddress = exports.getPNIDByPID = exports.getPNIDByUsername = exports.verifyConnected = exports.connection = exports.connect = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const joi_1 = __importDefault(require("joi"));
const util_1 = require("./util");
const pnid_1 = require("./models/pnid");
const server_1 = require("./models/server");
const logger_1 = require("./logger");
const config_manager_1 = require("./config-manager");
const token_types_1 = require("./types/common/token-types");
const system_types_1 = require("./types/common/system-types");
const connection_string = config_manager_1.config.mongoose.connection_string;
const options = config_manager_1.config.mongoose.options;
// TODO - Extend this later with more settings
const discordConnectionSchema = joi_1.default.object({
    id: joi_1.default.string()
});
const accessModeOrder = {
    prod: ['prod'],
    test: ['test', 'prod'],
    dev: ['dev', 'test', 'prod']
};
let _connection;
async function connect() {
    await mongoose_1.default.connect(connection_string, options);
    _connection = mongoose_1.default.connection;
    _connection.on('error', console.error.bind(console, 'connection error:'));
}
exports.connect = connect;
function connection() {
    return _connection;
}
exports.connection = connection;
function verifyConnected() {
    if (!connection()) {
        throw new Error('Cannot make database requets without being connected');
    }
}
exports.verifyConnected = verifyConnected;
async function getPNIDByUsername(username) {
    verifyConnected();
    return await pnid_1.PNID.findOne({
        usernameLower: username.toLowerCase()
    });
}
exports.getPNIDByUsername = getPNIDByUsername;
async function getPNIDByPID(pid) {
    verifyConnected();
    return await pnid_1.PNID.findOne({
        pid
    });
}
exports.getPNIDByPID = getPNIDByPID;
async function getPNIDByEmailAddress(email) {
    verifyConnected();
    // TODO - Update documents to store email normalized
    return await pnid_1.PNID.findOne({
        'email.address': email
    });
}
exports.getPNIDByEmailAddress = getPNIDByEmailAddress;
async function doesPNIDExist(username) {
    verifyConnected();
    return !!await getPNIDByUsername(username);
}
exports.doesPNIDExist = doesPNIDExist;
async function getPNIDByBasicAuth(token) {
    verifyConnected();
    // * Wii U sends Basic auth as `username password`, where the password may not have spaces
    // * This is not to spec, but that is the consoles fault not ours
    const decoded = Buffer.from(token, 'base64').toString();
    const parts = decoded.split(' ');
    const username = parts[0];
    const password = parts[1];
    const pnid = await getPNIDByUsername(username);
    if (!pnid) {
        return null;
    }
    const hashedPassword = (0, util_1.nintendoPasswordHash)(password, pnid.pid);
    if (!bcrypt_1.default.compareSync(hashedPassword, pnid.password)) {
        return null;
    }
    return pnid;
}
exports.getPNIDByBasicAuth = getPNIDByBasicAuth;
async function getPNIDByOAuthToken(token, expectedSystemType, expectedTokenType) {
    verifyConnected();
    try {
        const decryptedToken = (0, util_1.decryptToken)(Buffer.from(token, 'hex'));
        const unpackedToken = (0, util_1.unpackToken)(decryptedToken);
        if (unpackedToken.system_type !== expectedSystemType) {
            return null;
        }
        if (unpackedToken.token_type !== expectedTokenType) {
            return null;
        }
        const pnid = await getPNIDByPID(unpackedToken.pid);
        if (pnid) {
            const expireTime = Math.floor((Number(unpackedToken.expire_time) / 1000));
            if (Math.floor(Date.now() / 1000) > expireTime) {
                return null;
            }
        }
        return pnid;
    }
    catch (error) {
        // TODO - Handle error
        (0, logger_1.LOG_ERROR)(error);
        return null;
    }
}
async function getPNIDByNNASAccessToken(token) {
    return getPNIDByOAuthToken(token, system_types_1.SystemType.WUP, token_types_1.TokenType.OAuthAccess);
}
exports.getPNIDByNNASAccessToken = getPNIDByNNASAccessToken;
async function getPNIDByNNASRefreshToken(token) {
    return getPNIDByOAuthToken(token, system_types_1.SystemType.WUP, token_types_1.TokenType.OAuthRefresh);
}
exports.getPNIDByNNASRefreshToken = getPNIDByNNASRefreshToken;
async function getPNIDByAPIAccessToken(token) {
    return getPNIDByOAuthToken(token, system_types_1.SystemType.API, token_types_1.TokenType.OAuthAccess);
}
exports.getPNIDByAPIAccessToken = getPNIDByAPIAccessToken;
async function getPNIDByAPIRefreshToken(token) {
    return getPNIDByOAuthToken(token, system_types_1.SystemType.API, token_types_1.TokenType.OAuthRefresh);
}
exports.getPNIDByAPIRefreshToken = getPNIDByAPIRefreshToken;
async function getPNIDProfileJSONByPID(pid) {
    verifyConnected();
    const pnid = await getPNIDByPID(pid);
    if (!pnid) {
        return null;
    }
    const device = pnid.devices[0]; // * Just grab the first device
    let device_attributes = [];
    if (device) {
        device_attributes = device.device_attributes.map((attribute) => {
            const name = attribute.name;
            const value = attribute.value;
            const created_date = attribute.created_date;
            return {
                device_attribute: {
                    name,
                    value,
                    created_date: created_date ? created_date : ''
                }
            };
        });
    }
    return {
        // *accounts: {}, // * We need to figure this out, no idea what these values mean or what they do
        active_flag: pnid.flags.active ? 'Y' : 'N',
        birth_date: pnid.birthdate,
        country: pnid.country,
        create_date: pnid.creation_date,
        device_attributes: device_attributes,
        gender: pnid.gender,
        language: pnid.language,
        updated: pnid.updated,
        marketing_flag: pnid.flags.marketing ? 'Y' : 'N',
        off_device_flag: pnid.flags.off_device ? 'Y' : 'N',
        pid: pnid.pid,
        email: {
            address: pnid.email.address,
            id: pnid.email.id,
            parent: pnid.email.parent ? 'Y' : 'N',
            primary: pnid.email.primary ? 'Y' : 'N',
            reachable: pnid.email.reachable ? 'Y' : 'N',
            type: 'DEFAULT',
            updated_by: 'USER',
            validated: pnid.email.validated ? 'Y' : 'N',
            validated_date: pnid.email.validated ? pnid.email.validated_date : ''
        },
        mii: {
            status: 'COMPLETED',
            data: pnid.mii.data.replace(/(\r\n|\n|\r)/gm, ''),
            id: pnid.mii.id,
            mii_hash: pnid.mii.hash,
            mii_images: {
                mii_image: {
                    // * Images MUST be loaded over HTTPS or console ignores them
                    // * Bunny CDN is the only CDN which seems to support TLS 1.0/1.1 (required)
                    cached_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/standard.tga`,
                    id: pnid.mii.image_id,
                    url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/standard.tga`,
                    type: 'standard'
                }
            },
            name: pnid.mii.name,
            primary: pnid.mii.primary ? 'Y' : 'N'
        },
        region: pnid.region,
        tz_name: pnid.timezone.name,
        user_id: pnid.username,
        utc_offset: pnid.timezone.offset
    };
}
exports.getPNIDProfileJSONByPID = getPNIDProfileJSONByPID;
async function getServerByGameServerID(gameServerID, accessMode) {
    const searchModes = accessModeOrder[accessMode] ?? accessModeOrder.prod; // Default to prod if invalid mode
    const servers = await server_1.Server.find({
        game_server_id: gameServerID,
        access_mode: { $in: searchModes }
    });
    for (const mode of searchModes) {
        const server = servers.find(s => s.access_mode === mode);
        if (server) {
            return server;
        }
    }
    return null;
}
exports.getServerByGameServerID = getServerByGameServerID;
async function getServerByTitleID(titleID, accessMode) {
    const searchModes = accessModeOrder[accessMode] ?? accessModeOrder.prod;
    const servers = await server_1.Server.find({
        title_ids: titleID,
        access_mode: { $in: searchModes }
    });
    for (const mode of searchModes) {
        const server = servers.find(s => s.access_mode === mode);
        if (server) {
            return server;
        }
    }
    return null;
}
exports.getServerByTitleID = getServerByTitleID;
async function getServerByClientID(clientID, accessMode) {
    const searchModes = accessModeOrder[accessMode] ?? accessModeOrder.prod;
    const servers = await server_1.Server.find({
        client_id: clientID,
        access_mode: { $in: searchModes }
    });
    for (const mode of searchModes) {
        const server = servers.find(s => s.access_mode === mode);
        if (server) {
            return server;
        }
    }
    return null;
}
exports.getServerByClientID = getServerByClientID;
async function addPNIDConnection(pnid, data, type) {
    if (type === 'discord') {
        return await addPNIDConnectionDiscord(pnid, data);
    }
}
exports.addPNIDConnection = addPNIDConnection;
async function addPNIDConnectionDiscord(pnid, data) {
    const valid = discordConnectionSchema.validate(data);
    if (valid.error) {
        return {
            app: 'api',
            status: 400,
            error: 'Invalid or missing connection data'
        };
    }
    await pnid_1.PNID.updateOne({ pid: pnid.pid }, {
        $set: {
            'connections.discord.id': data.id
        }
    });
    return {
        app: 'api',
        status: 200
    };
}
exports.addPNIDConnectionDiscord = addPNIDConnectionDiscord;
async function removePNIDConnection(pnid, type) {
    // * Add more connections later?
    if (type === 'discord') {
        return await removePNIDConnectionDiscord(pnid);
    }
}
exports.removePNIDConnection = removePNIDConnection;
async function removePNIDConnectionDiscord(pnid) {
    await pnid_1.PNID.updateOne({ pid: pnid.pid }, {
        $set: {
            'connections.discord.id': ''
        }
    });
    return {
        app: 'api',
        status: 200
    };
}
exports.removePNIDConnectionDiscord = removePNIDConnectionDiscord;
