"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function CemuMiddleware(request, _response, next) {
    const subdomain = request.subdomains.reverse().join('.');
    request.isCemu = subdomain === 'c.account';
    return next();
}
exports.default = CemuMiddleware;
