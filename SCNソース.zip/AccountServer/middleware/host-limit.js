"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.restrictHostnames = void 0;
function restrictHostnames(allowedHostnames, fn) {
    return (request, response, next) => {
        if (allowedHostnames.includes(request.hostname)) {
            return fn(request, response, next);
        }
        return next();
    };
}
exports.restrictHostnames = restrictHostnames;
