"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_crypto_1 = __importDefault(require("node:crypto"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const util_1 = require("../util");
exports.default = (0, express_rate_limit_1.default)({
    windowMs: 60 * 1000,
    max: 1,
    keyGenerator: (request) => {
        let data = (0, util_1.getValueFromHeaders)(request.headers, 'x-nintendo-device-cert');
        if (!data) {
            data = request.ip;
        }
        return node_crypto_1.default.createHash('md5').update(data).digest('hex');
    }
});
