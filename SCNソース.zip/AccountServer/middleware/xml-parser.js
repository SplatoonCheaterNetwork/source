"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const xmlbuilder_1 = __importDefault(require("xmlbuilder"));
const xmlbuilder2_1 = require("xmlbuilder2");
const util_1 = require("../util");
function XMLMiddleware(request, response, next) {
    if (request.method == 'POST' || request.method == 'PUT') {
        const contentType = (0, util_1.getValueFromHeaders)(request.headers, 'content-type');
        const contentLength = (0, util_1.getValueFromHeaders)(request.headers, 'content-length');
        let body = '';
        if (!contentType ||
            !contentType.toLowerCase().includes('xml')) {
            return next();
        }
        if (!contentLength ||
            parseInt(contentLength) === 0) {
            return next();
        }
        request.setEncoding('utf-8');
        request.on('data', (chunk) => {
            body += chunk;
        });
        request.on('end', () => {
            try {
                request.body = (0, xmlbuilder2_1.document)(body);
                request.body = request.body.toObject();
                request.body = (0, util_1.mapToObject)(request.body);
            }
            catch {
                // TODO - This is not a real error code, check to see if better one exists
                return response.status(401).send(xmlbuilder_1.default.create({
                    errors: {
                        error: {
                            code: '0004',
                            message: 'XML parse error'
                        }
                    }
                }).end());
            }
            next();
        });
    }
    else {
        next();
    }
}
exports.default = XMLMiddleware;
