"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("../util");
const database_1 = require("../database");
const logger_1 = require("../logger");
async function APIMiddleware(request, _response, next) {
    const authHeader = (0, util_1.getValueFromHeaders)(request.headers, 'authorization');
    if (!authHeader || !(authHeader.startsWith('Bearer'))) {
        return next();
    }
    try {
        const token = authHeader.split(' ')[1];
        const pnid = await (0, database_1.getPNIDByAPIAccessToken)(token);
        request.pnid = pnid;
    }
    catch (error) {
        (0, logger_1.LOG_ERROR)('api middleware - decode pnid: ' + error);
        if (error.stack) {
            console.error(error.stack);
        }
    }
    return next();
}
exports.default = APIMiddleware;
