"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Device = exports.DeviceSchema = void 0;
const mongoose_1 = require("mongoose");
const DeviceAttributeSchema = new mongoose_1.Schema({
    created_date: String,
    name: String,
    value: String
});
exports.DeviceSchema = new mongoose_1.Schema({
    model: {
        type: String,
        enum: [
            'wup',
            'ctr',
            'spr',
            'ftr',
            'ktr',
            'red',
            'jan' // * New Nintendo 2DS XL
        ]
    },
    device_id: Number,
    device_type: Number,
    serial: String,
    device_attributes: [DeviceAttributeSchema],
    soap: {
        token: String,
        account_id: Number
    },
    environment: String,
    mac_hash: String,
    fcdcert_hash: String,
    linked_pids: [Number],
    access_level: {
        type: Number,
        default: 0 // * 0: standard, 1: tester, 2: mod?, 3: dev
    },
    server_access_level: {
        type: String,
        default: 'prod' // * everyone is in production by default
    },
    certificate_hash: String
});
exports.Device = (0, mongoose_1.model)('Device', exports.DeviceSchema);
