"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Server = void 0;
const mongoose_1 = require("mongoose");
const mongoose_unique_validator_1 = __importDefault(require("mongoose-unique-validator"));
const ServerSchema = new mongoose_1.Schema({
    client_id: String,
    ip: String,
    port: Number,
    service_name: String,
    service_type: String,
    game_server_id: String,
    title_ids: [String],
    access_mode: String,
    maintenance_mode: Boolean,
    device: Number,
    aes_key: String
});
ServerSchema.plugin(mongoose_unique_validator_1.default, { message: '{PATH} already in use.' });
exports.Server = (0, mongoose_1.model)('Server', ServerSchema);
