"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendMail = void 0;
const node_path_1 = __importDefault(require("node:path"));
const node_fs_1 = __importDefault(require("node:fs"));
const nodemailer_1 = __importDefault(require("nodemailer"));
const aws = __importStar(require("@aws-sdk/client-ses"));
const config_manager_1 = require("./config-manager");
const genericEmailTemplate = node_fs_1.default.readFileSync(node_path_1.default.join(__dirname, './assets/emails/genericTemplate.html'), 'utf8');
const confirmationEmailTemplate = node_fs_1.default.readFileSync(node_path_1.default.join(__dirname, './assets/emails/confirmationTemplate.html'), 'utf8');
let transporter;
if (!config_manager_1.disabledFeatures.email) {
    const ses = new aws.SES({
        apiVersion: '2010-12-01',
        region: config_manager_1.config.email.ses.region,
        credentials: {
            accessKeyId: config_manager_1.config.email.ses.key,
            secretAccessKey: config_manager_1.config.email.ses.secret
        }
    });
    transporter = transporter = nodemailer_1.default.createTransport({
        SES: {
            ses,
            aws
        }
    });
}
async function sendMail(options) {
    if (!config_manager_1.disabledFeatures.email) {
        const { to, subject, username, paragraph, preview, text, link, confirmation } = options;
        let html = confirmation ? confirmationEmailTemplate : genericEmailTemplate;
        html = html.replace(/{{username}}/g, username);
        html = html.replace(/{{paragraph}}/g, paragraph || '');
        html = html.replace(/{{preview}}/g, preview || '');
        html = html.replace(/{{confirmation-href}}/g, confirmation?.href || '');
        html = html.replace(/{{confirmation-code}}/g, confirmation?.code || '');
        if (link) {
            const { href, text } = link;
            const button = `<tr><td width="100%" height="16px" style="line-height: 16px;">&nbsp;</td></tr><tr><td class="confirm-link" bgcolor="#673db6" style="font-size: 14px; font-weight: 700; border-radius: 10px; padding: 12px" align="center"><a href="${href}" style="text-decoration: none; color: #ffffff; " width="100%">${text}</a></td></tr>`;
            html = html.replace(/<!--{{buttonPlaceholder}}-->/g, button);
        }
        await transporter.sendMail({
            from: config_manager_1.config.email.from,
            to,
            subject,
            text,
            html
        });
    }
}
exports.sendMail = sendMail;
