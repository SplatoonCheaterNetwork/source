"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setLocalCDNFile = exports.getLocalCDNFile = exports.getCachedFile = exports.setCachedFile = exports.connect = void 0;
const fs_extra_1 = __importDefault(require("fs-extra"));
const redis = __importStar(require("redis"));
const config_manager_1 = require("./config-manager");
let client;
const memoryCache = {};
const LOCAL_CDN_BASE = `${__dirname}/../cdn`;
async function connect() {
    if (!config_manager_1.disabledFeatures.redis) {
        client = redis.createClient(config_manager_1.config.redis.client);
        client.on('error', err => console.log('Redis Client Error', err));
        await client.connect();
    }
}
exports.connect = connect;
async function setCachedFile(fileName, value) {
    if (config_manager_1.disabledFeatures.redis) {
        memoryCache[fileName] = value;
    }
    else {
        await client.set(fileName, value);
    }
}
exports.setCachedFile = setCachedFile;
async function getCachedFile(fileName, encoding) {
    let cachedFile = Buffer.alloc(0);
    if (config_manager_1.disabledFeatures.redis) {
        cachedFile = memoryCache[fileName] || null;
    }
    else {
        const redisValue = await client.get(fileName);
        if (redisValue) {
            cachedFile = Buffer.from(redisValue, encoding);
        }
    }
    return cachedFile;
}
exports.getCachedFile = getCachedFile;
// * Local CDN cache functions
async function getLocalCDNFile(name, encoding) {
    let file = await getCachedFile(`local_cdn:${name}`, encoding);
    if (file === null) {
        if (await fs_extra_1.default.pathExists(`${LOCAL_CDN_BASE}/${name}`)) {
            const fileBuffer = await fs_extra_1.default.readFile(`${LOCAL_CDN_BASE}/${name}`, { encoding });
            file = Buffer.from(fileBuffer);
            await setLocalCDNFile(name, file);
        }
    }
    return file;
}
exports.getLocalCDNFile = getLocalCDNFile;
async function setLocalCDNFile(name, value) {
    await setCachedFile(`local_cdn:${name}`, value);
}
exports.setLocalCDNFile = setLocalCDNFile;
