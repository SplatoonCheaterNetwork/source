"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const logger_1 = require("../../logger");
const upload_1 = __importDefault(require("../../services/datastore/routes/upload"));
const host_limit_1 = require("../../middleware/host-limit");
const config_manager_1 = require("../../config-manager");
// * Router to handle the subdomain
const datastore = express_1.default.Router();
// * Setup routes
(0, logger_1.LOG_INFO)('[DATASTORE] Applying imported routes');
datastore.use(upload_1.default);
// * Main router for endpoints
const router = express_1.default.Router();
// * Create domains
(0, logger_1.LOG_INFO)(`[DATASTORE] Creating datastore router with domains: ${(0, logger_1.formatHostnames)(config_manager_1.config.domains.datastore)}`);
router.use((0, host_limit_1.restrictHostnames)(config_manager_1.config.domains.datastore, datastore));
exports.default = router;
