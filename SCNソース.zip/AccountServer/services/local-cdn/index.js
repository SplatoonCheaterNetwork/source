"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const config_manager_1 = require("../../config-manager");
const logger_1 = require("../../logger");
const get_1 = __importDefault(require("../../services/local-cdn/routes/get"));
const host_limit_1 = require("../../middleware/host-limit");
const router = express_1.default.Router();
if (config_manager_1.disabledFeatures.s3) {
    // * s3 disabled, setup local CDN
    // * Router to handle the subdomain
    const localcdn = express_1.default.Router();
    // * Setup routes
    (0, logger_1.LOG_INFO)('[LOCAL-CDN] Applying imported routes');
    localcdn.use(get_1.default);
    // * Create domains
    (0, logger_1.LOG_INFO)(`[LOCAL-CDN] Creating cdn router with domains: ${(0, logger_1.formatHostnames)(config_manager_1.config.domains.local_cdn)}`);
    router.use((0, host_limit_1.restrictHostnames)(config_manager_1.config.domains.local_cdn, localcdn));
}
else {
    (0, logger_1.LOG_INFO)('[LOCAL-CDN] s3 enabled, skipping local CDN');
}
exports.default = router;
