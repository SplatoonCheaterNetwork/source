"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cache_1 = require("../../../cache");
const router = express_1.default.Router();
router.get('/*', async (request, response) => {
    const filePath = request.params[0];
    const file = await (0, cache_1.getLocalCDNFile)(filePath);
    if (file) {
        response.send(file);
    }
    else {
        response.sendStatus(404);
    }
});
exports.default = router;
