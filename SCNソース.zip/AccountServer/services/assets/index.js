"use strict";
// * handles serving assets
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_path_1 = __importDefault(require("node:path"));
const express_1 = __importDefault(require("express"));
const logger_1 = require("../../logger");
const config_manager_1 = require("../../config-manager");
const host_limit_1 = require("../../middleware/host-limit");
// * Router to handle the subdomain restriction
const assets = express_1.default.Router();
// * Setup public folder
(0, logger_1.LOG_INFO)('[assets] Setting up public folder');
assets.use(express_1.default.static(node_path_1.default.join(__dirname, '../../assets')));
// * Main router for endpoints
const router = express_1.default.Router();
// * Create domains
(0, logger_1.LOG_INFO)(`[assets] Creating assets router with domains: ${(0, logger_1.formatHostnames)(config_manager_1.config.domains.assets)}`);
router.use((0, host_limit_1.restrictHostnames)(config_manager_1.config.domains.assets, assets));
exports.default = router;
