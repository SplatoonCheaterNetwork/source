"use strict";
// * handles NASC endpoints
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const nasc_1 = __importDefault(require("../../middleware/nasc"));
const logger_1 = require("../../logger");
const ac_1 = __importDefault(require("../../services/nasc/routes/ac"));
const host_limit_1 = require("../../middleware/host-limit");
const config_manager_1 = require("../../config-manager");
// * Router to handle the subdomain restriction
const nasc = express_1.default.Router();
(0, logger_1.LOG_INFO)('[NASC] Importing middleware');
nasc.use(nasc_1.default);
// * Setup routes
(0, logger_1.LOG_INFO)('[NASC] Applying imported routes');
nasc.use('/ac', ac_1.default);
// * Main router for endpoints
const router = express_1.default.Router();
// * Create domains
(0, logger_1.LOG_INFO)(`[NASC] Creating nasc router with domains: ${(0, logger_1.formatHostnames)(config_manager_1.config.domains.nasc)}`);
router.use((0, host_limit_1.restrictHostnames)(config_manager_1.config.domains.nasc, nasc));
exports.default = router;
