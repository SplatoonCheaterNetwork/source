"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const system_types_1 = require("../../../types/common/system-types");
const token_types_1 = require("../../../types/common/token-types");
const util_1 = require("../../../util");
const database_1 = require("../../../database");
const router = express_1.default.Router();
/**
 * [POST]
 * Replacement for: https://nasc.nintendowifi.net/ac
 * Description: Gets a NEX server address and token
 */
router.post('/', async (request, response) => {
    const requestParams = request.body;
    const action = (0, util_1.nintendoBase64Decode)(requestParams.action).toString();
    const titleID = (0, util_1.nintendoBase64Decode)(requestParams.titleid).toString();
    const nexAccount = request.nexAccount;
    let responseData = (0, util_1.nascError)('null');
    if (!nexAccount) {
        response.status(200).send(responseData.toString());
        return;
    }
    // TODO - REMOVE AFTER PUBLIC LAUNCH
    // * LET EVERYONE IN THE `test` FRIENDS SERVER
    // * THAT WAY EVERYONE CAN GET AN ASSIGNED PID
    let serverAccessLevel = 'test';
    if (titleID !== '0004013000003202') {
        serverAccessLevel = nexAccount.server_access_level;
    }
    const server = await (0, database_1.getServerByTitleID)(titleID, serverAccessLevel);
    if (!server || !server.aes_key) {
        response.status(200).send((0, util_1.nascError)('110').toString());
        return;
    }
    if (server.maintenance_mode) {
        // TODO - FIND THE REAL UNDER MAINTENANCE ERROR CODE. 110 IS NOT IT
        response.status(200).send((0, util_1.nascError)('110').toString());
        return;
    }
    if (action === 'LOGIN' && server.port <= 0 && server.ip !== '0.0.0.0') {
        // * Addresses of 0.0.0.0:0 are allowed
        // * They are expected for titles with no NEX server
        response.status(200).send((0, util_1.nascError)('110').toString());
        return;
    }
    switch (action) {
        case 'LOGIN':
            responseData = await processLoginRequest(server, nexAccount.pid, titleID);
            break;
        case 'SVCLOC':
            responseData = await processServiceTokenRequest(server, nexAccount.pid, titleID);
            break;
    }
    response.status(200).send(responseData.toString());
});
async function processLoginRequest(server, pid, titleID) {
    const tokenOptions = {
        system_type: system_types_1.SystemType.CTR,
        token_type: token_types_1.TokenType.NEX,
        pid: pid,
        access_level: 0,
        title_id: BigInt(parseInt(titleID, 16)),
        expire_time: BigInt(Date.now() + (3600 * 1000))
    };
    // TODO - Handle null tokens
    const nexTokenBuffer = await (0, util_1.generateToken)(server.aes_key, tokenOptions);
    const nexToken = (0, util_1.nintendoBase64Encode)(nexTokenBuffer || '');
    return new URLSearchParams({
        locator: (0, util_1.nintendoBase64Encode)(`${server.ip}:${server.port}`),
        retry: (0, util_1.nintendoBase64Encode)('0'),
        returncd: (0, util_1.nintendoBase64Encode)('001'),
        token: nexToken,
        datetime: (0, util_1.nintendoBase64Encode)((0, util_1.nascDateTime)())
    });
}
async function processServiceTokenRequest(server, pid, titleID) {
    const tokenOptions = {
        system_type: system_types_1.SystemType.CTR,
        token_type: token_types_1.TokenType.IndependentService,
        pid: pid,
        access_level: 0,
        title_id: BigInt(parseInt(titleID, 16)),
        expire_time: BigInt(Date.now()) // TODO - Hack. Independent services expire their own tokens, so we give them the ISSUED time, not an EXPIRE time
    };
    // TODO - Handle null tokens
    const serviceTokenBuffer = await (0, util_1.generateToken)(server.aes_key, tokenOptions);
    const serviceToken = (0, util_1.nintendoBase64Encode)(serviceTokenBuffer || '');
    return new URLSearchParams({
        retry: (0, util_1.nintendoBase64Encode)('0'),
        returncd: (0, util_1.nintendoBase64Encode)('007'),
        servicetoken: serviceToken,
        statusdata: (0, util_1.nintendoBase64Encode)('Y'),
        svchost: (0, util_1.nintendoBase64Encode)('n/a'),
        datetime: (0, util_1.nintendoBase64Encode)((0, util_1.nascDateTime)())
    });
}
exports.default = router;
