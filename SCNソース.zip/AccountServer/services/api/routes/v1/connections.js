"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const database_1 = require("../../../../database");
const router = express_1.default.Router();
const VALID_CONNECTION_TYPES = [
    'discord'
];
/**
 * [POST]
 * Implementation of for: https://api.pretendo.cc/v1/connections/add/TYPE
 * Description: Adds an account connection to the users PNID
 */
router.post('/add/:type', async (request, response) => {
    const data = request.body?.data;
    const pnid = request.pnid;
    const type = request.params.type;
    if (!pnid) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing access token'
        });
        return;
    }
    if (!data) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing connection data'
        });
        return;
    }
    if (!VALID_CONNECTION_TYPES.includes(type)) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing connection type'
        });
        return;
    }
    let result = await (0, database_1.addPNIDConnection)(pnid, data, type);
    if (!result) {
        result = {
            app: 'api',
            status: 500,
            error: 'Unknown server error'
        };
    }
    response.status(result.status || 500).json(result);
});
/**
 * [DELETE]
 * Implementation of for: https://api.pretendo.cc/v1/connections/remove/TYPE
 * Description: Removes an account connection from the users PNID
 */
router.delete('/remove/:type', async (request, response) => {
    const pnid = request.pnid;
    const type = request.params.type;
    if (!pnid) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing access token'
        });
        return;
    }
    if (!VALID_CONNECTION_TYPES.includes(type)) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing connection type'
        });
        return;
    }
    let result = await (0, database_1.removePNIDConnection)(pnid, type);
    if (!result) {
        result = {
            app: 'api',
            status: 500,
            error: 'Unknown server error'
        };
    }
    response.status(result.status).json(result);
});
exports.default = router;
