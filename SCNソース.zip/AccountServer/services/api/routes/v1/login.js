"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const database_1 = require("../../../../database");
const util_1 = require("../../../../util");
const system_types_1 = require("../../../../types/common/system-types");
const token_types_1 = require("../../../../types/common/token-types");
const config_manager_1 = require("../../../../config-manager");
const logger_1 = require("../../../../logger");
const router = express_1.default.Router();
/**
 * [POST]
 * Implementation of for: https://api.pretendo.cc/v1/login
 * Description: Generates an access token for an API user
 * TODO: Replace this with a more robust OAuth2 implementation
 */
router.post('/', async (request, response) => {
    const grantType = request.body?.grant_type;
    const username = request.body?.username;
    const password = request.body?.password;
    const refreshToken = request.body?.refresh_token;
    if (!['password', 'refresh_token'].includes(grantType)) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid grant type'
        });
        return;
    }
    if (grantType === 'password' && (!username || username.trim() === '')) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing username'
        });
        return;
    }
    if (grantType === 'password' && (!password || password.trim() === '')) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing password'
        });
        return;
    }
    if (grantType === 'refresh_token' && (!refreshToken || refreshToken.trim() === '')) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing refresh token'
        });
        return;
    }
    let pnid;
    if (grantType === 'password') {
        pnid = await (0, database_1.getPNIDByUsername)(username);
        if (!pnid) {
            response.status(400).json({
                app: 'api',
                status: 400,
                error: 'User not found'
            });
            return;
        }
        const hashedPassword = (0, util_1.nintendoPasswordHash)(password, pnid.pid);
        if (!pnid || !bcrypt_1.default.compareSync(hashedPassword, pnid.password)) {
            response.status(400).json({
                app: 'api',
                status: 400,
                error: 'Invalid or missing password'
            });
            return;
        }
    }
    else {
        pnid = await (0, database_1.getPNIDByAPIRefreshToken)(refreshToken);
        if (!pnid) {
            response.status(400).json({
                app: 'api',
                status: 400,
                error: 'Invalid or missing refresh token'
            });
            return;
        }
    }
    if (pnid.deleted) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'User not found'
        });
        return;
    }
    const accessTokenOptions = {
        system_type: system_types_1.SystemType.API,
        token_type: token_types_1.TokenType.OAuthAccess,
        pid: pnid.pid,
        access_level: pnid.access_level,
        title_id: BigInt(0),
        expire_time: BigInt(Date.now() + (3600 * 1000))
    };
    const refreshTokenOptions = {
        system_type: system_types_1.SystemType.API,
        token_type: token_types_1.TokenType.OAuthRefresh,
        pid: pnid.pid,
        access_level: pnid.access_level,
        title_id: BigInt(0),
        expire_time: BigInt(Date.now() + 12 * 3600 * 1000)
    };
    try {
        const accessTokenBuffer = await (0, util_1.generateToken)(config_manager_1.config.aes_key, accessTokenOptions);
        const refreshTokenBuffer = await (0, util_1.generateToken)(config_manager_1.config.aes_key, refreshTokenOptions);
        const accessToken = accessTokenBuffer ? accessTokenBuffer.toString('hex') : '';
        const newRefreshToken = refreshTokenBuffer ? refreshTokenBuffer.toString('hex') : '';
        // TODO - Handle null tokens
        response.json({
            access_token: accessToken,
            token_type: 'Bearer',
            expires_in: 3600,
            refresh_token: newRefreshToken
        });
    }
    catch (error) {
        (0, logger_1.LOG_ERROR)('/v1/login - token generation: ' + error);
        if (error.stack) {
            console.error(error.stack);
        }
        response.status(500).json({
            app: 'api',
            status: 500,
            error: 'Internal server error'
        });
    }
});
exports.default = router;
