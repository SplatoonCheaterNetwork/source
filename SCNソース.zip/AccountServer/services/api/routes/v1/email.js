"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const moment_1 = __importDefault(require("moment"));
const pnid_1 = require("../../../../models/pnid");
const util_1 = require("../../../../util");
const router = express_1.default.Router();
router.get('/verify', async (request, response) => {
    const token = (0, util_1.getValueFromQueryString)(request.query, 'token');
    if (!token || token.trim() == '') {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Missing email token'
        });
        return;
    }
    const pnid = await pnid_1.PNID.findOne({
        'identification.email_token': token
    });
    if (!pnid) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid email token'
        });
        return;
    }
    const validatedDate = (0, moment_1.default)().format('YYYY-MM-DDTHH:MM:SS');
    pnid.email.reachable = true;
    pnid.email.validated = true;
    pnid.email.validated_date = validatedDate;
    await pnid.save();
    await (0, util_1.sendEmailConfirmedEmail)(pnid);
    response.status(200).send('Email validated. You may close this window');
});
exports.default = router;
