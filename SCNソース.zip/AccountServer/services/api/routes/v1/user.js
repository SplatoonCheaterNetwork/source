"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const zod_1 = require("zod");
const mii_js_1 = __importDefault(require("mii-js"));
const config_manager_1 = require("../../../../config-manager");
const pnid_1 = require("../../../../models/pnid");
const router = express_1.default.Router();
// TODO - Extend this later with more settings
const userSchema = zod_1.z.object({
    mii: zod_1.z.object({
        name: zod_1.z.string().trim(),
        primary: zod_1.z.enum(['Y', 'N']),
        data: zod_1.z.string()
    }).optional(),
    environment: zod_1.z.enum(['prod', 'test', 'dev']).optional()
});
/**
 * [GET]
 * Implementation of for: https://api.pretendo.cc/v1/user
 * Description: Gets PNID details about the current user
 */
router.get('/', async (request, response) => {
    const pnid = request.pnid;
    if (!pnid) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing access token'
        });
        return;
    }
    response.json({
        access_level: pnid.access_level,
        server_access_level: pnid.server_access_level,
        pid: pnid.pid,
        creation_date: pnid.creation_date,
        updated: pnid.updated,
        username: pnid.username,
        birthdate: pnid.birthdate,
        gender: pnid.gender,
        country: pnid.country,
        email: {
            address: pnid.email.address
        },
        timezone: {
            name: pnid.timezone.name
        },
        mii: {
            data: pnid.mii.data,
            name: pnid.mii.name,
            image_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/normal_face.png`
        },
        flags: {
            marketing: pnid.flags.marketing
        },
        connections: {
            discord: {
                id: pnid.connections.discord.id
            },
            stripe: {
                tier_name: pnid.connections.stripe.tier_name,
                tier_level: pnid.connections.stripe.tier_level
            }
        }
    });
});
/**
 * [POST]
 * Implementation of for: https://api.pretendo.cc/v1/user
 * Description: Updates PNID certain details about the current user
 */
router.post('/', async (request, response) => {
    const pnid = request.pnid;
    const updateUserRequest = request.body;
    if (!pnid) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing access token'
        });
        return;
    }
    const result = userSchema.safeParse(updateUserRequest);
    if (!result.success) {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: result.error
        });
        return;
    }
    if (result.data.mii) {
        const miiNameBuffer = Buffer.from(result.data.mii.name, 'utf16le'); // * UTF8 to UTF16
        if (miiNameBuffer.length < 1) {
            response.status(400).json({
                app: 'api',
                status: 400,
                error: 'Mii name too short'
            });
            return;
        }
        if (miiNameBuffer.length > 0x14) {
            response.status(400).json({
                app: 'api',
                status: 400,
                error: 'Mii name too long'
            });
            return;
        }
        try {
            const miiDataBuffer = Buffer.from(result.data.mii.data, 'base64');
            if (miiDataBuffer.length < 0x60) {
                response.status(400).json({
                    app: 'api',
                    status: 400,
                    error: 'Mii data too short'
                });
                return;
            }
            if (miiDataBuffer.length > 0x60) {
                response.status(400).json({
                    app: 'api',
                    status: 400,
                    error: 'Mii data too long'
                });
                return;
            }
            const mii = new mii_js_1.default(miiDataBuffer);
            mii.validate();
        }
        catch {
            response.status(400).json({
                app: 'api',
                status: 400,
                error: 'Failed to decode Mii data'
            });
            return;
        }
        await pnid.updateMii({
            name: result.data.mii.name,
            primary: result.data.mii.primary,
            data: result.data.mii.data
        });
    }
    const updateData = {};
    if (result.data.environment) {
        const environment = result.data.environment;
        if (environment === 'test' && pnid.access_level < 1) {
            response.status(400).json({
                app: 'api',
                status: 400,
                error: 'Do not have permission to enter this environment'
            });
            return;
        }
        if (environment === 'dev' && pnid.access_level < 3) {
            response.status(400).json({
                app: 'api',
                status: 400,
                error: 'Do not have permission to enter this environment'
            });
            return;
        }
        updateData.server_access_level = environment;
    }
    await pnid_1.PNID.updateOne({ pid: pnid.pid }, { $set: updateData }).exec();
    response.json({
        access_level: pnid.access_level,
        server_access_level: pnid.server_access_level,
        pid: pnid.pid,
        creation_date: pnid.creation_date,
        updated: pnid.updated,
        username: pnid.username,
        birthdate: pnid.birthdate,
        gender: pnid.gender,
        country: pnid.country,
        email: {
            address: pnid.email.address
        },
        timezone: {
            name: pnid.timezone.name
        },
        mii: {
            data: pnid.mii.data,
            name: pnid.mii.name,
            image_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/normal_face.png`
        },
        flags: {
            marketing: pnid.flags.marketing
        },
        connections: {
            discord: {
                id: pnid.connections.discord.id
            }
        }
    });
});
exports.default = router;
