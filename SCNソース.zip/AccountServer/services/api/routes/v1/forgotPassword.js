"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const validator_1 = __importDefault(require("validator"));
const hcaptcha_1 = __importDefault(require("hcaptcha"));
const database_1 = require("../../../../database");
const util_1 = require("../../../../util");
const config_manager_1 = require("../../../../config-manager");
const router = express_1.default.Router();
router.post('/', async (request, response) => {
    const input = request.body?.input;
    const hCaptchaResponse = request.body.hCaptchaResponse?.trim();
    if (!config_manager_1.disabledFeatures.captcha) {
        if (!hCaptchaResponse || hCaptchaResponse === '') {
            response.status(400).json({
                app: 'api',
                status: 400,
                error: 'Must fill in captcha'
            });
            return;
        }
        const captchaVerify = await hcaptcha_1.default.verify(config_manager_1.config.hcaptcha.secret, hCaptchaResponse);
        if (!captchaVerify.success) {
            response.status(400).json({
                app: 'api',
                status: 400,
                error: 'Captcha verification failed'
            });
            return;
        }
    }
    if (!input || input.trim() === '') {
        response.status(400).json({
            app: 'api',
            status: 400,
            error: 'Invalid or missing input'
        });
        return;
    }
    let pnid;
    if (validator_1.default.isEmail(input)) {
        pnid = await (0, database_1.getPNIDByEmailAddress)(input);
    }
    else {
        pnid = await (0, database_1.getPNIDByUsername)(input);
    }
    if (pnid) {
        await (0, util_1.sendForgotPasswordEmail)(pnid);
    }
    response.json({
        app: 'api',
        status: 200
    });
});
exports.default = router;
