"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.V1 = void 0;
const connections_1 = __importDefault(require("../../../services/api/routes/v1/connections"));
const email_1 = __importDefault(require("../../../services/api/routes/v1/email"));
const forgotPassword_1 = __importDefault(require("../../../services/api/routes/v1/forgotPassword"));
const login_1 = __importDefault(require("../../../services/api/routes/v1/login"));
const register_1 = __importDefault(require("../../../services/api/routes/v1/register"));
const resetPassword_1 = __importDefault(require("../../../services/api/routes/v1/resetPassword"));
const user_1 = __importDefault(require("../../../services/api/routes/v1/user"));
exports.V1 = {
    CONNECTIONS: connections_1.default,
    EMAIL: email_1.default,
    FORGOT_PASSWORD: forgotPassword_1.default,
    LOGIN: login_1.default,
    REGISTER: register_1.default,
    RESET_PASSWORD: resetPassword_1.default,
    USER: user_1.default
};
