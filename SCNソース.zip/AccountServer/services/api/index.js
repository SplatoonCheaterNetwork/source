"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const api_1 = __importDefault(require("../../middleware/api"));
const logger_1 = require("../../logger");
const routes_1 = require("../../services/api/routes");
const config_manager_1 = require("../../config-manager");
const host_limit_1 = require("../../middleware/host-limit");
// * Router to handle the subdomain restriction
const api = express_1.default.Router();
(0, logger_1.LOG_INFO)('[USER API] Importing middleware');
api.use(api_1.default);
api.use((0, cors_1.default)());
api.options('*', (0, cors_1.default)());
// * Setup routes
(0, logger_1.LOG_INFO)('[USER API] Applying imported routes');
api.use('/v1/connections', routes_1.V1.CONNECTIONS);
api.use('/v1/email', routes_1.V1.EMAIL);
api.use('/v1/forgot-password', routes_1.V1.FORGOT_PASSWORD);
api.use('/v1/login', routes_1.V1.LOGIN);
api.use('/v1/register', routes_1.V1.REGISTER);
api.use('/v1/reset-password', routes_1.V1.RESET_PASSWORD);
api.use('/v1/user', routes_1.V1.USER);
// * Main router for endpoints
const router = express_1.default.Router();
// * Create domains
(0, logger_1.LOG_INFO)(`[USER API] Registering api router with domains: ${(0, logger_1.formatHostnames)(config_manager_1.config.domains.api)}`);
router.use((0, host_limit_1.restrictHostnames)(config_manager_1.config.domains.api, api));
exports.default = router;
