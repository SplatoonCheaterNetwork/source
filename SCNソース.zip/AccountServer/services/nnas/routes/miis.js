"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const xmlbuilder_1 = __importDefault(require("xmlbuilder"));
const util_1 = require("../../../util");
const pnid_1 = require("../../../models/pnid");
const config_manager_1 = require("../../../config-manager");
const router = express_1.default.Router();
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/miis
 * Description: Returns a list of NNID miis
 */
router.get('/', async (request, response) => {
    const input = (0, util_1.getValueFromQueryString)(request.query, 'pids');
    if (!input) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'Bad Request',
                    code: '1600',
                    message: 'Unable to process request'
                }
            }
        }).end());
        return;
    }
    const pids = input.split(',').map(pid => Number(pid)).filter(pid => !isNaN(pid));
    const miis = [];
    for (const pid of pids) {
        // TODO - Replace this with a single query again somehow? Maybe aggregation?
        const pnid = await pnid_1.PNID.findOne({ pid });
        if (pnid) {
            miis.push({
                data: pnid.mii.data.replace(/(\r\n|\n|\r)/gm, ''),
                id: pnid.mii.id,
                images: {
                    image: [
                        {
                            cached_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/normal_face.png`,
                            id: pnid.mii.id,
                            url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/normal_face.png`,
                            type: 'standard'
                        },
                        {
                            cached_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/frustrated.png`,
                            id: pnid.mii.id,
                            url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/frustrated.png`,
                            type: 'frustrated_face'
                        },
                        {
                            cached_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/smile_open_mouth.png`,
                            id: pnid.mii.id,
                            url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/smile_open_mouth.png`,
                            type: 'happy_face'
                        },
                        {
                            cached_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/wink_left.png`,
                            id: pnid.mii.id,
                            url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/wink_left.png`,
                            type: 'like_face'
                        },
                        {
                            cached_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/normal_face.png`,
                            id: pnid.mii.id,
                            url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/normal_face.png`,
                            type: 'normal_face'
                        },
                        {
                            cached_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/sorrow.png`,
                            id: pnid.mii.id,
                            url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/sorrow.png`,
                            type: 'puzzled_face'
                        },
                        {
                            cached_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/surprised_open_mouth.png`,
                            id: pnid.mii.id,
                            url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/surprised_open_mouth.png`,
                            type: 'surprised_face'
                        },
                        {
                            cached_url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/body.png`,
                            id: pnid.mii.id,
                            url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/body.png`,
                            type: 'whole_body'
                        }
                    ]
                },
                name: pnid.mii.name,
                pid: pnid.pid,
                primary: pnid.mii.primary ? 'Y' : 'N',
                user_id: pnid.username
            });
        }
    }
    if (miis.length === 0) {
        response.status(404).end();
    }
    else {
        response.send(xmlbuilder_1.default.create({
            miis: {
                mii: miis
            }
        }).end());
    }
});
exports.default = router;
