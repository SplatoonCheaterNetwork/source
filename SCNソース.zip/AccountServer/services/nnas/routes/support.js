"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_dns_1 = __importDefault(require("node:dns"));
const express_1 = __importDefault(require("express"));
const xmlbuilder_1 = __importDefault(require("xmlbuilder"));
const moment_1 = __importDefault(require("moment"));
const database_1 = require("../../../database");
const device_1 = require("../../../models/device");
const util_1 = require("../../../util");
// * Middleware to ensure the input device is valid
// TODO - Make this available for more routes? This could be useful elsewhere
async function validateDeviceIDMiddleware(request, response, next) {
    const deviceID = request.header('x-nintendo-device-id');
    const serial = request.header('x-nintendo-serial-number');
    // * Since these values are linked at the time of device creation, and the
    // * device ID is always validated against the device certificate for legitimacy
    // * we can safely assume that every console hitting our servers through normal
    // * means will be stored correctly. And since once both values are set they
    // * cannot be changed, these checks will always be safe
    const device = await device_1.Device.findOne({
        device_id: Number(deviceID),
        serial: serial
    });
    if (!device) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'device_id',
                    code: '0113',
                    message: 'Unauthorized device'
                }
            }
        }).end());
        return;
    }
    if (device.access_level < 0) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '0012',
                    message: 'Device has been banned by game server' // TODO - This is not the right error message
                }
            }
        }).end());
        return;
    }
    // TODO - Once we push support for linking PNIDs to consoles, also check if the PID is linked or not
    next();
}
const router = express_1.default.Router();
/**
 * [POST]
 * Replacement for: https://account.nintendo.net/v1/api/support/validate/email
 * Description: Verifies a provided email address is valid
 */
router.post('/validate/email', async (request, response) => {
    const email = request.body.email;
    if (!email) {
        response.send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'email',
                    code: '0103',
                    message: 'Email format is invalid'
                }
            }
        }).end());
        return;
    }
    const domain = email.split('@')[1];
    node_dns_1.default.resolveMx(domain, (error) => {
        if (error) {
            return response.send(xmlbuilder_1.default.create({
                errors: {
                    error: {
                        code: '1126',
                        message: 'The domain "' + domain + '" is not accessible.'
                    }
                }
            }).end());
        }
        response.send();
    });
});
/**
 * [PUT]
 * Replacement for: https://account.nintendo.net/v1/api/support/email_confirmation/:pid/:code
 * Description: Verifies a users email via 6 digit code
 */
router.put('/email_confirmation/:pid/:code', async (request, response) => {
    const code = request.params.code;
    const pid = Number(request.params.pid);
    const pnid = await (0, database_1.getPNIDByPID)(pid);
    if (!pnid) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '0130',
                    message: 'PID has not been registered yet'
                }
            }
        }).end());
        return;
    }
    if (pnid.identification.email_code !== code) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '0116',
                    message: 'Missing or invalid verification code'
                }
            }
        }).end());
        return;
    }
    const validatedDate = (0, moment_1.default)().format('YYYY-MM-DDTHH:MM:SS');
    pnid.email.reachable = true;
    pnid.email.validated = true;
    pnid.email.validated_date = validatedDate;
    await pnid.save();
    await (0, util_1.sendEmailConfirmedEmail)(pnid);
    response.status(200).send('');
});
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/support/resend_confirmation
 * Description: Resends a users confirmation email
 */
router.get('/resend_confirmation', validateDeviceIDMiddleware, async (request, response) => {
    const pid = Number(request.headers['x-nintendo-pid']);
    const pnid = await (0, database_1.getPNIDByPID)(pid);
    if (!pnid) {
        // TODO - Unsure if this is the right error
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '0130',
                    message: 'PID has not been registered yet'
                }
            }
        }).end());
        return;
    }
    await (0, util_1.sendConfirmationEmail)(pnid);
    response.status(200).send('');
});
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/support/send_confirmation/pin/:email
 * Description: Sends a users confirmation email that their email has been registered for parental controls
 */
router.get('/send_confirmation/pin/:email', async (request, response) => {
    const email = request.params.email;
    const pnid = await (0, database_1.getPNIDByEmailAddress)(email);
    if (!pnid) {
        // TODO - Unsure if this is the right error
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '0130',
                    message: 'PID has not been registered yet'
                }
            }
        }).end());
        return;
    }
    await (0, util_1.sendEmailConfirmedParentalControlsEmail)(pnid);
    response.status(200).send('');
});
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/support/forgotten_password/PID
 * Description: Sends the user a password reset email
 * NOTE: On NN this was a temp password that expired after 24 hours. We do not do that
 */
router.get('/forgotten_password/:pid', validateDeviceIDMiddleware, async (request, response) => {
    const pid = Number(request.params.pid);
    const pnid = await (0, database_1.getPNIDByPID)(pid);
    if (!pnid) {
        // TODO - Better errors
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'device_id',
                    code: '0113',
                    message: 'Unauthorized device'
                }
            }
        }).end());
        return;
    }
    await (0, util_1.sendForgotPasswordEmail)(pnid);
    response.status(200).send('');
});
exports.default = router;
