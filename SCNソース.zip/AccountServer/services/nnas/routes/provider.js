"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const xmlbuilder_1 = __importDefault(require("xmlbuilder"));
const database_1 = require("../../../database");
const util_1 = require("../../../util");
const token_types_1 = require("../../../types/common/token-types");
const nex_account_1 = require("../../../models/nex-account");
const router = express_1.default.Router();
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/provider/service_token/@me
 * Description: Gets a service token
 */
router.get('/service_token/@me', async (request, response) => {
    const pnid = request.pnid;
    if (!pnid) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'access_token',
                    code: '0002',
                    message: 'Invalid access token'
                }
            }
        }).end());
        return;
    }
    const clientID = (0, util_1.getValueFromQueryString)(request.query, 'client_id');
    if (!clientID) {
        // TODO - Research this error more
        response.send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '1021',
                    message: 'The requested game server was not found'
                }
            }
        }).end());
        return;
    }
    const titleID = (0, util_1.getValueFromHeaders)(request.headers, 'x-nintendo-title-id');
    if (!titleID) {
        // TODO - Research this error more
        response.send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '1021',
                    message: 'The requested game server was not found'
                }
            }
        }).end());
        return;
    }
    const serverAccessLevel = pnid.server_access_level;
    const server = await (0, database_1.getServerByClientID)(clientID, serverAccessLevel);
    if (!server || !server.aes_key) {
        response.send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '1021',
                    message: 'The requested game server was not found'
                }
            }
        }).end());
        return;
    }
    if (server.maintenance_mode) {
        response.send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '2002',
                    message: 'The requested game server is under maintenance'
                }
            }
        }).end());
        return;
    }
    const tokenOptions = {
        system_type: server.device,
        token_type: token_types_1.TokenType.IndependentService,
        pid: pnid.pid,
        access_level: pnid.access_level,
        title_id: BigInt(parseInt(titleID, 16)),
        expire_time: BigInt(Date.now()) // TODO - Hack. Independent services expire their own tokens, so we give them the ISSUED time, not an EXPIRE time
    };
    const serviceTokenBuffer = await (0, util_1.generateToken)(server.aes_key, tokenOptions);
    let serviceToken = serviceTokenBuffer ? serviceTokenBuffer.toString('base64') : '';
    if (request.isCemu) {
        serviceToken = Buffer.from(serviceToken, 'base64').toString('hex');
    }
    response.send(xmlbuilder_1.default.create({
        service_token: {
            token: serviceToken
        }
    }).end());
});
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/provider/nex_token/@me
 * Description: Gets a NEX server address and token
 */
router.get('/nex_token/@me', async (request, response) => {
    const pnid = request.pnid;
    if (!pnid) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'access_token',
                    code: '0002',
                    message: 'Invalid access token'
                }
            }
        }).end());
        return;
    }
    const nexAccount = await nex_account_1.NEXAccount.findOne({
        owning_pid: pnid.pid
    });
    if (!nexAccount) {
        response.status(404).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: '',
                    code: '0008',
                    message: 'Not Found'
                }
            }
        }).end());
        return;
    }
    const gameServerID = (0, util_1.getValueFromQueryString)(request.query, 'game_server_id');
    if (!gameServerID) {
        response.send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '0118',
                    message: 'Unique ID and Game Server ID are not linked'
                }
            }
        }).end());
        return;
    }
    const serverAccessLevel = pnid.server_access_level;
    const server = await (0, database_1.getServerByGameServerID)(gameServerID, serverAccessLevel);
    if (!server || !server.aes_key) {
        response.send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '1021',
                    message: 'The requested game server was not found'
                }
            }
        }).end());
        return;
    }
    if (server.maintenance_mode) {
        response.send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '2002',
                    message: 'The requested game server is under maintenance'
                }
            }
        }).end());
        return;
    }
    const titleID = (0, util_1.getValueFromHeaders)(request.headers, 'x-nintendo-title-id');
    if (!titleID) {
        // TODO - Research this error more
        response.send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '1021',
                    message: 'The requested game server was not found'
                }
            }
        }).end());
        return;
    }
    const tokenOptions = {
        system_type: server.device,
        token_type: token_types_1.TokenType.NEX,
        pid: pnid.pid,
        access_level: pnid.access_level,
        title_id: BigInt(parseInt(titleID, 16)),
        expire_time: BigInt(Date.now() + (3600 * 1000))
    };
    const nexTokenBuffer = await (0, util_1.generateToken)(server.aes_key, tokenOptions);
    let nexToken = nexTokenBuffer ? nexTokenBuffer.toString('base64') : '';
    if (request.isCemu) {
        nexToken = Buffer.from(nexToken || '', 'base64').toString('hex');
    }
    response.send(xmlbuilder_1.default.create({
        nex_token: {
            host: server.ip,
            nex_password: nexAccount.password,
            pid: nexAccount.pid,
            port: server.port,
            token: nexToken
        }
    }).end());
});
exports.default = router;
