"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_crypto_1 = __importDefault(require("node:crypto"));
const express_1 = __importDefault(require("express"));
const xmlbuilder_1 = __importDefault(require("xmlbuilder"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const moment_1 = __importDefault(require("moment"));
const device_certificate_1 = __importDefault(require("../../../middleware/device-certificate"));
const ratelimit_1 = __importDefault(require("../../../middleware/ratelimit"));
const database_1 = require("../../../database");
const util_1 = require("../../../util");
const pnid_1 = require("../../../models/pnid");
const nex_account_1 = require("../../../models/nex-account");
const logger_1 = require("../../../logger");
const timezones_json_1 = __importDefault(require("../../../services/nnas/timezones.json"));
const router = express_1.default.Router();
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/people/:USERNAME
 * Description: Checks if a username is in use
 */
router.get('/:username', async (request, response) => {
    const username = request.params.username;
    const userExists = await (0, database_1.doesPNIDExist)(username);
    if (userExists) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '0100',
                    message: 'Account ID already exists'
                }
            }
        }).end());
        return;
    }
    response.send();
});
/**
 * [POST]
 * Replacement for: https://account.nintendo.net/v1/api/people
 * Description: Registers a new NNID
 */
router.post('/', ratelimit_1.default, device_certificate_1.default, async (request, response) => {
    if (!request.certificate || !request.certificate.valid) {
        // TODO - Change this to a different error
        response.status(400).send(xmlbuilder_1.default.create({
            error: {
                cause: 'Bad Request',
                code: '1600',
                message: 'Unable to process request'
            }
        }).end());
        return;
    }
    const person = request.body.person;
    const userExists = await (0, database_1.doesPNIDExist)(person.user_id);
    if (userExists) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '0100',
                    message: 'Account ID already exists'
                }
            }
        }).end());
        return;
    }
    const creationDate = (0, moment_1.default)().format('YYYY-MM-DDTHH:MM:SS');
    let pnid;
    let nexAccount;
    const session = await (0, database_1.connection)().startSession();
    await session.startTransaction();
    try {
        nexAccount = new nex_account_1.NEXAccount({
            device_type: 'wiiu'
        });
        await nexAccount.generatePID();
        await nexAccount.generatePassword();
        // * Quick hack to get the PIDs to match
        // TODO - Change this maybe?
        // * NN with a NNID will always use the NNID PID
        // * even if the provided NEX PID is different
        // * To fix this we make them the same PID
        nexAccount.owning_pid = nexAccount.pid;
        await nexAccount.save({ session });
        const primaryPasswordHash = (0, util_1.nintendoPasswordHash)(person.password, nexAccount.pid);
        const passwordHash = await bcrypt_1.default.hash(primaryPasswordHash, 10);
        const countryCode = person.country;
        const language = person.language;
        const timezoneName = person.tz_name;
        const regionLanguages = timezones_json_1.default[countryCode];
        const regionTimezones = regionLanguages[language] ? regionLanguages[language] : Object.values(regionLanguages)[0];
        let timezone = regionTimezones.find(tz => tz.area === timezoneName);
        if (!timezone) {
            // TODO - Change this, handle the error
            timezone = {
                area: 'America/New_York',
                language: 'en',
                name: 'Eastern Time (US &amp; Canada)',
                order: '11',
                utc_offset: '-14400'
            };
        }
        pnid = new pnid_1.PNID({
            pid: nexAccount.pid,
            creation_date: creationDate,
            updated: creationDate,
            username: person.user_id,
            usernameLower: person.user_id.toLowerCase(),
            password: passwordHash,
            birthdate: person.birth_date,
            gender: person.gender,
            country: countryCode,
            language: language,
            email: {
                address: person.email.address.toLowerCase(),
                primary: person.email.primary === 'Y',
                parent: person.email.parent === 'Y',
                reachable: false,
                validated: person.email.validated === 'Y',
                id: node_crypto_1.default.randomBytes(4).readUInt32LE()
            },
            region: person.region,
            timezone: {
                name: timezoneName,
                offset: Number(timezone.utc_offset)
            },
            mii: {
                name: person.mii.name,
                primary: person.mii.name === 'Y',
                data: person.mii.data,
                id: node_crypto_1.default.randomBytes(4).readUInt32LE(),
                hash: node_crypto_1.default.randomBytes(7).toString('hex'),
                image_url: '',
                image_id: node_crypto_1.default.randomBytes(4).readUInt32LE()
            },
            flags: {
                active: true,
                marketing: person.marketing_flag === 'Y',
                off_device: person.off_device_flag === 'Y'
            },
            identification: {
                email_code: 1,
                email_token: '' // * will be overwritten before saving
            }
        });
        await pnid.generateEmailValidationCode();
        await pnid.generateEmailValidationToken();
        await pnid.generateMiiImages();
        await pnid.save({ session });
        await session.commitTransaction();
    }
    catch (error) {
        (0, logger_1.LOG_ERROR)('[POST] /v1/api/people: ' + error);
        await session.abortTransaction();
        response.status(400).send(xmlbuilder_1.default.create({
            error: {
                cause: 'Bad Request',
                code: '1600',
                message: 'Unable to process request'
            }
        }).end());
        return;
    }
    finally {
        // * This runs regardless of failure
        // * Returning on catch will not prevent this from running
        await session.endSession();
    }
    await (0, util_1.sendConfirmationEmail)(pnid);
    response.send(xmlbuilder_1.default.create({
        person: {
            pid: pnid.pid
        }
    }).end());
});
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/profile
 * Description: Gets a users profile
 */
router.get('/@me/profile', async (request, response) => {
    response.set('Content-Type', 'text/xml');
    response.set('Server', 'Nintendo 3DS (http)');
    response.set('X-Nintendo-Date', new Date().getTime().toString());
    const pnid = request.pnid;
    if (!pnid) {
        // TODO - Research this error more
        response.status(404).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: '',
                    code: '0008',
                    message: 'Not Found'
                }
            }
        }).end());
        return;
    }
    const person = await (0, database_1.getPNIDProfileJSONByPID)(pnid.pid);
    if (!person) {
        // TODO - Research this error more
        response.status(404).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: '',
                    code: '0008',
                    message: 'Not Found'
                }
            }
        }).end());
        return;
    }
    response.send(xmlbuilder_1.default.create({
        person
    }, { separateArrayItems: true }).end());
});
/**
 * [POST]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/devices
 * Description: Gets user profile, seems to be the same as https://account.nintendo.net/v1/api/people/@me/profile
 */
router.post('/@me/devices', async (request, response) => {
    response.set('Content-Type', 'text/xml');
    response.set('Server', 'Nintendo 3DS (http)');
    response.set('X-Nintendo-Date', new Date().getTime().toString());
    // * We don't care about the device attributes
    // * The console ignores them and PNIDs are not tied to consoles anyway
    // * So the server also ignores them and does not save the ones posted here
    // TODO - CHANGE THIS. WE NEED TO SAVE CONSOLE DETAILS !!!
    const pnid = request.pnid;
    if (!pnid) {
        // TODO - Research this error more
        response.status(404).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: '',
                    code: '0008',
                    message: 'Not Found'
                }
            }
        }).end());
        return;
    }
    const person = await (0, database_1.getPNIDProfileJSONByPID)(pnid.pid);
    if (!person) {
        // TODO - Research this error more
        response.status(404).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: '',
                    code: '0008',
                    message: 'Not Found'
                }
            }
        }).end());
        return;
    }
    response.send(xmlbuilder_1.default.create({
        person
    }).end());
});
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/devices
 * Description: Returns only user devices
 */
router.get('/@me/devices', async (request, response) => {
    response.set('Content-Type', 'text/xml');
    response.set('Server', 'Nintendo 3DS (http)');
    response.set('X-Nintendo-Date', new Date().getTime().toString());
    const pnid = request.pnid;
    const deviceID = (0, util_1.getValueFromHeaders)(request.headers, 'x-nintendo-device-id');
    const acceptLanguage = (0, util_1.getValueFromHeaders)(request.headers, 'accept-language');
    const platformID = (0, util_1.getValueFromHeaders)(request.headers, 'x-nintendo-platform-id');
    const region = (0, util_1.getValueFromHeaders)(request.headers, 'x-nintendo-region');
    const serialNumber = (0, util_1.getValueFromHeaders)(request.headers, 'x-nintendo-serial-number');
    const systemVersion = (0, util_1.getValueFromHeaders)(request.headers, 'x-nintendo-system-version');
    if (!deviceID || !acceptLanguage || !platformID || !region || !serialNumber || !systemVersion) {
        // TODO - Research these error more
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'Bad Request',
                    code: '1600',
                    message: 'Unable to process request'
                }
            }
        }).end());
        return;
    }
    if (!pnid) {
        // TODO - Research this error more
        response.status(404).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: '',
                    code: '0008',
                    message: 'Not Found'
                }
            }
        }).end());
        return;
    }
    response.send(xmlbuilder_1.default.create({
        devices: [
            {
                device: {
                    device_id: deviceID,
                    language: acceptLanguage,
                    updated: (0, moment_1.default)().format('YYYY-MM-DDTHH:MM:SS'),
                    pid: pnid.pid,
                    platform_id: platformID,
                    region: region,
                    serial_number: serialNumber,
                    status: 'ACTIVE',
                    system_version: systemVersion,
                    type: 'RETAIL',
                    updated_by: 'USER'
                }
            }
        ]
    }).end());
});
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/devices/owner
 * Description: Gets user profile, seems to be the same as https://account.nintendo.net/v1/api/people/@me/profile
 */
router.get('/@me/devices/owner', async (request, response) => {
    response.set('Content-Type', 'text/xml');
    response.set('Server', 'Nintendo 3DS (http)');
    response.set('X-Nintendo-Date', (0, moment_1.default)().add(5, 'h').toString());
    const pnid = request.pnid;
    if (!pnid) {
        // TODO - Research this error more
        response.status(404).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: '',
                    code: '0008',
                    message: 'Not Found'
                }
            }
        }).end());
        return;
    }
    const person = await (0, database_1.getPNIDProfileJSONByPID)(pnid.pid);
    if (!person) {
        // TODO - Research this error more
        response.status(404).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: '',
                    code: '0008',
                    message: 'Not Found'
                }
            }
        }).end());
        return;
    }
    response.send(xmlbuilder_1.default.create({
        person
    }).end());
});
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/devices/status
 * Description: Unknown use
 */
router.get('/@me/devices/status', async (_request, response) => {
    response.set('Content-Type', 'text/xml');
    response.set('Server', 'Nintendo 3DS (http)');
    response.set('X-Nintendo-Date', (0, moment_1.default)().add(5, 'h').toString());
    response.send(xmlbuilder_1.default.create({
        device: {}
    }).end());
});
/**
 * [PUT]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/miis/@primary
 * Description: Updates a users Mii
 */
router.put('/@me/miis/@primary', async (request, response) => {
    const pnid = request.pnid;
    if (!pnid) {
        // TODO - Research this error more
        response.status(404).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: '',
                    code: '0008',
                    message: 'Not Found'
                }
            }
        }).end());
        return;
    }
    const mii = request.body.mii;
    // TODO - Better checks
    const name = mii.name;
    const primary = mii.primary;
    const data = mii.data;
    await pnid.updateMii({ name, primary, data });
    response.send('');
});
/**
 * [PUT]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/devices/@current/inactivate
 * Description: Deactivates a user from a console
 */
router.put('/@me/devices/@current/inactivate', async (request, response) => {
    response.set('Server', 'Nintendo 3DS (http)');
    response.set('X-Nintendo-Date', new Date().getTime().toString());
    const pnid = request.pnid;
    if (!pnid) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'access_token',
                    code: '0002',
                    message: 'Invalid access token'
                }
            }
        }).end());
        return;
    }
    response.send();
});
/**
 * [POST]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/deletion
 * Description: Deletes a NNID
 */
router.post('/@me/deletion', async (request, response) => {
    const pnid = request.pnid;
    if (!pnid) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'access_token',
                    code: '0002',
                    message: 'Invalid access token'
                }
            }
        }).end());
        return;
    }
    const email = pnid.email.address;
    await pnid.scrub();
    await pnid.save();
    try {
        await (0, util_1.sendPNIDDeletedEmail)(email, pnid.username);
    }
    catch (error) {
        (0, logger_1.LOG_ERROR)(`Error sending deletion email ${error}`);
    }
    response.send('');
});
/**
 * [PUT]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/
 * Description: Updates a PNIDs account details
 */
router.put('/@me', async (request, response) => {
    const pnid = request.pnid;
    const person = request.body.person;
    if (!pnid) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'access_token',
                    code: '0002',
                    message: 'Invalid access token'
                }
            }
        }).end());
        return;
    }
    const gender = person.gender ? person.gender : pnid.gender;
    const region = person.region ? person.region : pnid.region;
    const countryCode = person.country ? person.country : pnid.country;
    const language = person.language ? person.language : pnid.language;
    let timezoneName = person.tz_name ? person.tz_name : pnid.timezone.name;
    // * Fix for 3DS sending empty person.tz_name, which is interpreted as an empty object
    // TODO - See if there's a cleaner way to do this?
    if (typeof timezoneName === 'object' && Object.keys(timezoneName).length === 0) {
        timezoneName = pnid.timezone.name;
    }
    const marketingFlag = person.marketing_flag ? person.marketing_flag === 'Y' : pnid.flags.marketing;
    const offDeviceFlag = person.off_device_flag ? person.off_device_flag === 'Y' : pnid.flags.off_device;
    const regionLanguages = timezones_json_1.default[countryCode];
    const regionTimezones = regionLanguages[language] ? regionLanguages[language] : Object.values(regionLanguages)[0];
    let timezone = regionTimezones.find(tz => tz.area === timezoneName);
    if (!timezone) {
        // TODO - Change this, handle the error
        timezone = {
            area: 'America/New_York',
            language: 'en',
            name: 'Eastern Time (US &amp; Canada)',
            order: '11',
            utc_offset: '-14400'
        };
    }
    if (person.password) {
        const primaryPasswordHash = (0, util_1.nintendoPasswordHash)(person.password, pnid.pid);
        const passwordHash = await bcrypt_1.default.hash(primaryPasswordHash, 10);
        pnid.password = passwordHash;
    }
    pnid.gender = gender;
    pnid.region = region;
    pnid.country = countryCode;
    pnid.language = language;
    pnid.timezone.name = timezoneName;
    pnid.timezone.offset = Number(timezone.utc_offset);
    pnid.flags.marketing = marketingFlag;
    pnid.flags.off_device = offDeviceFlag;
    await pnid.save();
    response.send('');
});
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/emails/
 * Description: Gets a list (why?) of PNID emails
 */
router.get('/@me/emails', async (request, response) => {
    const pnid = request.pnid;
    if (!pnid) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'access_token',
                    code: '0002',
                    message: 'Invalid access token'
                }
            }
        }).end());
        return;
    }
    response.send(xmlbuilder_1.default.create({
        emails: [
            {
                email: {
                    address: pnid.email.address,
                    id: pnid.email.id,
                    parent: pnid.email.parent ? 'Y' : 'N',
                    primary: pnid.email.primary ? 'Y' : 'N',
                    reachable: pnid.email.reachable ? 'Y' : 'N',
                    type: 'DEFAULT',
                    updated_by: 'USER',
                    validated: pnid.email.validated ? 'Y' : 'N',
                    validated_date: pnid.email.validated_date
                }
            }
        ]
    }).end());
});
/**
 * [PUT]
 * Replacement for: https://account.nintendo.net/v1/api/people/@me/emails/@primary
 * Description: Updates a users email address
 */
router.put('/@me/emails/@primary', async (request, response) => {
    const pnid = request.pnid;
    const email = request.body.email;
    if (!pnid || !email || !email.address) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    cause: 'access_token',
                    code: '0002',
                    message: 'Invalid access token'
                }
            }
        }).end());
        return;
    }
    // TODO - Better email check
    pnid.email.address = email.address.toLowerCase();
    pnid.email.reachable = false;
    pnid.email.validated = false;
    pnid.email.validated_date = '';
    pnid.email.id = node_crypto_1.default.randomBytes(4).readUInt32LE();
    await pnid.generateEmailValidationCode();
    await pnid.generateEmailValidationToken();
    await pnid.save();
    await (0, util_1.sendConfirmationEmail)(pnid);
    response.send('');
});
exports.default = router;
