"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const xmlbuilder_1 = __importDefault(require("xmlbuilder"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const device_certificate_1 = __importDefault(require("../../../middleware/device-certificate"));
const console_status_verification_1 = __importDefault(require("../../../middleware/console-status-verification"));
const database_1 = require("../../../database");
const util_1 = require("../../../util");
const system_types_1 = require("../../../types/common/system-types");
const token_types_1 = require("../../../types/common/token-types");
const config_manager_1 = require("../../../config-manager");
const device_1 = require("../../../models/device");
const router = express_1.default.Router();
/**
 * [POST]
 * Replacement for: https://account.nintendo.net/v1/api/oauth20/access_token/generate
 * Description: Generates an access token for a user
 */
router.post('/access_token/generate', device_certificate_1.default, console_status_verification_1.default, async (request, response) => {
    const grantType = request.body.grant_type;
    const username = request.body.user_id;
    const password = request.body.password;
    const refreshToken = request.body.refresh_token;
    if (!['password', 'refresh_token'].includes(grantType)) {
        response.status(400).send(xmlbuilder_1.default.create({
            error: {
                cause: 'grant_type',
                code: '0004',
                message: 'Invalid Grant Type'
            }
        }).end());
        return;
    }
    let pnid = null;
    if (grantType === 'password') {
        if (!username || username.trim() === '') {
            response.status(400).send(xmlbuilder_1.default.create({
                error: {
                    cause: 'user_id',
                    code: '0002',
                    message: 'user_id format is invalid'
                }
            }).end());
            return;
        }
        if (!password || password.trim() === '') {
            response.status(400).send(xmlbuilder_1.default.create({
                error: {
                    cause: 'password',
                    code: '0002',
                    message: 'password format is invalid'
                }
            }).end());
            return;
        }
        pnid = await (0, database_1.getPNIDByUsername)(username);
        if (!pnid || !await bcrypt_1.default.compare(password, pnid.password)) {
            response.status(400).send(xmlbuilder_1.default.create({
                errors: {
                    error: {
                        code: '0106',
                        message: 'Invalid account ID or password'
                    }
                }
            }).end({ pretty: true }));
            return;
        }
    }
    else {
        if (!refreshToken || refreshToken.trim() === '') {
            response.status(400).send(xmlbuilder_1.default.create({
                error: {
                    cause: 'refresh_token',
                    code: '0106',
                    message: 'Invalid Refresh Token'
                }
            }).end());
            return;
        }
        try {
            pnid = await (0, database_1.getPNIDByNNASRefreshToken)(refreshToken);
            if (!pnid) {
                response.status(400).send(xmlbuilder_1.default.create({
                    error: {
                        cause: 'refresh_token',
                        code: '0106',
                        message: 'Invalid Refresh Token'
                    }
                }).end());
                return;
            }
        }
        catch {
            response.status(400).send(xmlbuilder_1.default.create({
                error: {
                    cause: 'refresh_token',
                    code: '0106',
                    message: 'Invalid Refresh Token'
                }
            }).end());
            return;
        }
    }
    if (pnid.deleted) {
        // * 0112 is the "account deleted" error, but unsure if this unlinks the PNID from the user?
        // * 0143 is the "The link to this Nintendo Network ID has been temporarliy removed" error,
        // * maybe that is a better error to use here?
        response.status(400).send(xmlbuilder_1.default.create({
            error: {
                code: '0112',
                message: pnid.username
            }
        }).end());
        return;
    }
    // * This are set/validated in consoleStatusVerificationMiddleware
    // * It is always set, despite what Express might think
    await device_1.Device.updateOne({
        _id: request.device._id
    }, {
        $addToSet: {
            linked_pids: pnid.pid
        }
    });
    if (pnid.access_level < 0) {
        response.status(400).send(xmlbuilder_1.default.create({
            errors: {
                error: {
                    code: '0108',
                    message: 'Account has been banned'
                }
            }
        }).end());
        return;
    }
    const accessTokenOptions = {
        system_type: system_types_1.SystemType.WUP,
        token_type: token_types_1.TokenType.OAuthAccess,
        pid: pnid.pid,
        expire_time: BigInt(Date.now() + (3600 * 1000))
    };
    const refreshTokenOptions = {
        system_type: system_types_1.SystemType.WUP,
        token_type: token_types_1.TokenType.OAuthRefresh,
        pid: pnid.pid,
        expire_time: BigInt(Date.now() + 12 * 3600 * 1000)
    };
    const accessTokenBuffer = await (0, util_1.generateToken)(config_manager_1.config.aes_key, accessTokenOptions);
    const refreshTokenBuffer = await (0, util_1.generateToken)(config_manager_1.config.aes_key, refreshTokenOptions);
    const accessToken = accessTokenBuffer ? accessTokenBuffer.toString('hex') : '';
    const newRefreshToken = refreshTokenBuffer ? refreshTokenBuffer.toString('hex') : '';
    // TODO - Handle null tokens
    response.send(xmlbuilder_1.default.create({
        OAuth20: {
            access_token: {
                token: accessToken,
                refresh_token: newRefreshToken,
                expires_in: 3600
            }
        }
    }).end());
});
exports.default = router;
