"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_crypto_1 = __importDefault(require("node:crypto"));
const express_1 = __importDefault(require("express"));
const got_1 = __importDefault(require("got"));
const zod_1 = require("zod");
const database_1 = require("../../../database");
const logger_1 = require("../../../logger");
const util_1 = require("../../../util");
const config_manager_1 = require("../../../config-manager");
const timezones_json_1 = __importDefault(require("../../../services/nnas/timezones.json"));
const regions_json_1 = __importDefault(require("../../../services/nnas/regions.json"));
const router = express_1.default.Router();
const accountSettingsSchema = zod_1.z.object({
    birthdate: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    gender: zod_1.z.enum(['M', 'F']),
    tz_name: zod_1.z.string(),
    region: zod_1.z.coerce.number(),
    country: zod_1.z.string(),
    email: zod_1.z.string().email(),
    server_selection: zod_1.z.enum(['prod', 'test', 'dev']),
    marketing_flag: zod_1.z.enum(['true', 'false']).transform(value => value === 'true'),
    off_device_flag: zod_1.z.enum(['true', 'false']).transform(value => value === 'true')
});
/**
 * [GET]
 * Replacement for: https://account.nintendo.net/v1/account-settings/ui/profile
 * Description: Serves the Nintendo Network ID Settings page for the Wii U
 */
router.get('/ui/profile', async function (request, response) {
    const server = await (0, database_1.getServerByClientID)('3f3928cc6f780638d360f0485cef973f', config_manager_1.config.server_environment);
    const token = (0, util_1.getValueFromHeaders)(request.headers, 'x-nintendo-service-token');
    if (!server || !token) {
        response.sendStatus(504);
        return;
    }
    const aes_key = server?.aes_key;
    const decryptedToken = (0, util_1.decryptToken)(Buffer.from(token, 'base64'), aes_key);
    const tokenContents = (0, util_1.unpackToken)(decryptedToken);
    try {
        const PNID = await (0, database_1.getPNIDByPID)(tokenContents.pid);
        if (!PNID) {
            response.sendStatus(504);
            return;
        }
        const countryCode = PNID.country;
        const language = PNID.language;
        const regionLanguages = timezones_json_1.default[countryCode];
        const regionTimezones = regionLanguages[language] ? regionLanguages[language] : Object.values(regionLanguages)[0];
        const region = regions_json_1.default.find(region => region.iso_code === countryCode);
        const miiFaces = ['normal_face', 'smile_open_mouth', 'sorrow', 'surprise_open_mouth', 'wink_left', 'frustrated'];
        const face = miiFaces[node_crypto_1.default.randomInt(5)];
        const notice = request.query.notice ? request.query.notice.toString() : undefined;
        const accountLevel = ['Standard', 'Tester', 'Moderator', 'Developer'];
        response.render('index.ejs', {
            PNID,
            regionTimezones,
            face,
            notice,
            accountLevel,
            regions: region ? region.regions : [],
            regionsList: regions_json_1.default
        });
    }
    catch (error) {
        (0, logger_1.LOG_ERROR)(error);
        response.sendStatus(504);
        return;
    }
});
/**
 * [GET]
 * Description: Fetches the requested mii image from the CDN and send it to the client.
 * This is required because of the strict domain whitelist in the account settings app
 * on the Wii U.
 */
router.get('/mii/:pid/:face', async function (request, response) {
    if (!config_manager_1.config.cdn.base_url) {
        response.sendStatus(404);
        return;
    }
    try {
        const url = `${config_manager_1.config.cdn.base_url}/mii/${request.params.pid}/${request.params.face}.png`;
        console.log(url);
        const miiImage = await (0, got_1.default)(url).buffer();
        response.set('Content-Type', 'image/png');
        response.send(miiImage);
    }
    catch (error) {
        (0, logger_1.LOG_ERROR)(error);
        response.sendStatus(404);
        return;
    }
});
/**
 * [POST]
 * Description: Endpoint to update the PNID from the account settings app on the Wii
 */
router.post('/update', async function (request, response) {
    const server = await (0, database_1.getServerByClientID)('3f3928cc6f780638d360f0485cef973f', config_manager_1.config.server_environment);
    const token = (0, util_1.getValueFromHeaders)(request.headers, 'x-nintendo-service-token');
    if (!server || !token) {
        response.sendStatus(504);
        return;
    }
    const aesKey = server?.aes_key;
    const decryptedToken = (0, util_1.decryptToken)(Buffer.from(token, 'base64'), aesKey);
    const tokenContents = (0, util_1.unpackToken)(decryptedToken);
    try {
        const pnid = await (0, database_1.getPNIDByPID)(tokenContents.pid);
        const personBody = request.body;
        if (!pnid) {
            response.status(404);
            response.redirect('/v1/account-settings/ui/profile');
            return;
        }
        const person = accountSettingsSchema.safeParse(personBody);
        if (!person.success) {
            response.status(404);
            response.redirect('/v1/account-settings/ui/profile');
            return;
        }
        const timezoneName = (person.data.tz_name && !!Object.keys(person.data.tz_name).length) ? person.data.tz_name : pnid.timezone.name;
        const regionLanguages = timezones_json_1.default[pnid.country];
        const regionTimezones = regionLanguages[pnid.language] ? regionLanguages[pnid.language] : Object.values(regionLanguages)[0];
        const timezone = regionTimezones.find(tz => tz.area === timezoneName);
        const country = regions_json_1.default.find(region => region.iso_code === pnid.country);
        let notice = '';
        if (!country) {
            response.status(404);
            response.redirect('/v1/account-settings/ui/profile');
            return;
        }
        const regionObject = country.regions.find(region => region.id === person.data.region);
        const region = regionObject ? regionObject.id : pnid.region;
        if (!timezone) {
            response.status(404);
            response.redirect('/v1/account-settings/ui/profile');
            return;
        }
        pnid.birthdate = person.data.birthdate;
        pnid.gender = person.data.gender;
        pnid.region = region;
        pnid.country = person.data.country;
        pnid.timezone.name = timezoneName;
        pnid.timezone.offset = Number(timezone.utc_offset);
        pnid.flags.marketing = person.data.marketing_flag;
        pnid.flags.off_device = person.data.off_device_flag;
        if (person.data.server_selection && pnid.access_level > 0 && pnid.access_level < 4) {
            const environment = person.data.server_selection;
            if (environment === 'test' && pnid.access_level < 1) {
                response.status(400);
                notice = 'Do not have permission to enter this environment';
                response.redirect(`/v1/account-settings/ui/profile?notice=${notice}`);
                return;
            }
            if (environment === 'dev' && pnid.access_level < 3) {
                response.status(400);
                notice = 'Do not have permission to enter this environment';
                response.redirect(`/v1/account-settings/ui/profile?notice=${notice}`);
                return;
            }
            pnid.server_access_level = environment;
        }
        if (person.data.email.trim().toLowerCase() !== pnid.email.address) {
            // TODO - Better email check
            pnid.email.address = person.data.email.trim().toLowerCase();
            pnid.email.reachable = false;
            pnid.email.validated = false;
            pnid.email.validated_date = '';
            pnid.email.id = node_crypto_1.default.randomBytes(4).readUInt32LE();
            await pnid.generateEmailValidationCode();
            await pnid.generateEmailValidationToken();
            await (0, util_1.sendConfirmationEmail)(pnid);
            notice = 'A confirmation email has been sent to your inbox.';
        }
        await pnid.save();
        response.redirect(`/v1/account-settings/ui/profile?notice=${notice}`);
    }
    catch (error) {
        (0, logger_1.LOG_ERROR)(error);
        response.sendStatus(504);
        return;
    }
});
exports.default = router;
