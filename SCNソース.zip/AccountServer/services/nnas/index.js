"use strict";
// * handles "account.nintendo.net" endpoints
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_path_1 = __importDefault(require("node:path"));
const express_1 = __importDefault(require("express"));
const client_header_1 = __importDefault(require("../../middleware/client-header"));
const cemu_1 = __importDefault(require("../../middleware/cemu"));
const pnid_1 = __importDefault(require("../../middleware/pnid"));
const logger_1 = require("../../logger");
const admin_1 = __importDefault(require("../../services/nnas/routes/admin"));
const content_1 = __importDefault(require("../../services/nnas/routes/content"));
const devices_1 = __importDefault(require("../../services/nnas/routes/devices"));
const miis_1 = __importDefault(require("../../services/nnas/routes/miis"));
const oauth_1 = __importDefault(require("../../services/nnas/routes/oauth"));
const people_1 = __importDefault(require("../../services/nnas/routes/people"));
const provider_1 = __importDefault(require("../../services/nnas/routes/provider"));
const support_1 = __importDefault(require("../../services/nnas/routes/support"));
const account_settings_1 = __importDefault(require("../../services/nnas/routes/account-settings"));
const config_manager_1 = require("../../config-manager");
const host_limit_1 = require("../../middleware/host-limit");
// * Router to handle the subdomain restriction
const nnas = express_1.default.Router();
// * Static routes for the user information app
async function setCSSHeader(request, response, next) {
    response.set('Content-Type', 'text/css');
    return next();
}
async function setJSHeader(request, response, next) {
    response.set('Content-Type', 'text/javascript');
    return next();
}
async function setIMGHeader(request, response, next) {
    response.set('Content-Type', 'image/png');
    return next();
}
// * Setup routes
(0, logger_1.LOG_INFO)('[NNAS] Applying imported routes');
nnas.use('/v1/account-settings/', account_settings_1.default);
nnas.use('/v1/account-settings/css/', setCSSHeader, express_1.default.static(node_path_1.default.join(__dirname, '../../assets/user-info-settings')));
nnas.use('/v1/account-settings/js/', setJSHeader, express_1.default.static(node_path_1.default.join(__dirname, '../../assets/user-info-settings')));
nnas.use('/v1/account-settings/img/', setIMGHeader, express_1.default.static(node_path_1.default.join(__dirname, '../../assets/user-info-settings')));
(0, logger_1.LOG_INFO)('[NNAS] Importing middleware');
nnas.use(client_header_1.default);
nnas.use(cemu_1.default);
nnas.use(pnid_1.default);
nnas.use('/v1/api/admin', admin_1.default);
nnas.use('/v1/api/content', content_1.default);
nnas.use('/v1/api/devices', devices_1.default);
nnas.use('/v1/api/miis', miis_1.default);
nnas.use('/v1/api/oauth20', oauth_1.default);
nnas.use('/v1/api/people', people_1.default);
nnas.use('/v1/api/provider', provider_1.default);
nnas.use('/v1/api/support', support_1.default);
// * Main router for endpoints
const router = express_1.default.Router();
// * Create domains
(0, logger_1.LOG_INFO)(`[NNAS] Creating nnas router with domains: ${(0, logger_1.formatHostnames)(config_manager_1.config.domains.nnas)}`);
router.use((0, host_limit_1.restrictHostnames)(config_manager_1.config.domains.nnas, nnas));
exports.default = router;
