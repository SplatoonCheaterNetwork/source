"use strict";
// * handles CBVC (CTR Browser Version Check?) endpoints
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const logger_1 = require("../../logger");
const config_manager_1 = require("../../config-manager");
const host_limit_1 = require("../../middleware/host-limit");
// * Router to handle the subdomain restriction
const cbvc = express_1.default.Router();
// * Setup route
(0, logger_1.LOG_INFO)('[CBVC] Applying imported routes');
cbvc.get('/:consoleType/:unknown/:region', (request, response) => {
    response.set('Content-Type', 'text/plain');
    // * https://www.3dbrew.org/wiki/Internet_Browser#Forced_system-update
    // * The returned value is a number which the Internet Browser then compares
    // * with its own version number. If the version number isn't higher than the
    // * returned value, it will show a console update message.
    // *
    // * Return 0 and allow any browser to connect.
    response.send('0');
});
// * Main router for endpoints
const router = express_1.default.Router();
// * Create domains
(0, logger_1.LOG_INFO)(`[CBVC] Creating cbvc router with domains: ${(0, logger_1.formatHostnames)(config_manager_1.config.domains.cbvc)}`);
router.use((0, host_limit_1.restrictHostnames)(config_manager_1.config.domains.cbvc, cbvc));
exports.default = router;
