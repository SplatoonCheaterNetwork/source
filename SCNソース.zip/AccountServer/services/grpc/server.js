"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.startGRPCServer = void 0;
const nice_grpc_1 = require("nice-grpc");
const account_service_1 = require("@pretendonetwork/grpc/account/account_service");
const api_service_1 = require("@pretendonetwork/grpc/api/api_service");
const account_service_2 = require("@pretendonetwork/grpc/account/v2/account_service");
const api_service_2 = require("@pretendonetwork/grpc/api/v2/api_service");
const api_key_middleware_1 = require("../../services/grpc/account/v1/api-key-middleware");
const api_key_middleware_2 = require("../../services/grpc/api/v1/api-key-middleware");
const authentication_middleware_1 = require("../../services/grpc/api/v1/authentication-middleware");
const implementation_1 = require("../../services/grpc/account/v1/implementation");
const implementation_2 = require("../../services/grpc/api/v1/implementation");
const api_key_middleware_3 = require("../../services/grpc/account/v2/api-key-middleware");
const api_key_middleware_4 = require("../../services/grpc/api/v2/api-key-middleware");
const authentication_middleware_2 = require("../../services/grpc/api/v2/authentication-middleware");
const implementation_3 = require("../../services/grpc/account/v2/implementation");
const implementation_4 = require("../../services/grpc/api/v2/implementation");
const config_manager_1 = require("../../config-manager");
async function startGRPCServer() {
    const server = (0, nice_grpc_1.createServer)();
    server.with(api_key_middleware_1.apiKeyMiddleware).add(account_service_1.AccountDefinition, implementation_1.accountServiceImplementationV1);
    server.with(api_key_middleware_2.apiKeyMiddleware).with(authentication_middleware_1.authenticationMiddleware).add(api_service_1.APIDefinition, implementation_2.apiServiceImplementationV1);
    server.with(api_key_middleware_3.apiKeyMiddleware).add(account_service_2.AccountServiceDefinition, implementation_3.accountServiceImplementationV2);
    server.with(api_key_middleware_4.apiKeyMiddleware).with(authentication_middleware_2.authenticationMiddleware).add(api_service_2.ApiServiceDefinition, implementation_4.apiServiceImplementationV2);
    await server.listen(`0.0.0.0:${config_manager_1.config.grpc.port}`);
}
exports.startGRPCServer = startGRPCServer;
