"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setStripeConnectionData = void 0;
const nice_grpc_1 = require("nice-grpc");
const pnid_1 = require("../../../../models/pnid");
async function setStripeConnectionData(request, context) {
    // * This is asserted in authentication-middleware, we know this is never null
    const pnid = context.pnid;
    const updateData = {
        'connections.stripe.latest_webhook_timestamp': Number(request.timestamp)
    };
    if (request.customerId && !pnid.connections.stripe.customer_id) {
        updateData['connections.stripe.customer_id'] = request.customerId;
    }
    if (request.subscriptionId !== undefined) {
        updateData['connections.stripe.subscription_id'] = request.subscriptionId;
    }
    if (request.subscriptionId !== undefined) {
        updateData['connections.stripe.subscription_id'] = request.subscriptionId;
    }
    if (request.priceId !== undefined) {
        updateData['connections.stripe.price_id'] = request.priceId;
    }
    if (request.tierLevel !== undefined) {
        updateData['connections.stripe.tier_level'] = request.tierLevel;
    }
    if (request.tierName !== undefined) {
        updateData['connections.stripe.tier_name'] = request.tierName;
    }
    try {
        if (pnid.connections.stripe.latest_webhook_timestamp && pnid.connections.stripe.customer_id) {
            // * Stripe customer data has already been initialized, update it
            await pnid_1.PNID.updateOne({
                'pid': pnid.pid,
                'connections.stripe.latest_webhook_timestamp': {
                    $lte: request.timestamp
                }
            }, { $set: updateData }).exec();
        }
        else {
            // * Initialize a new Stripe user
            if (!request.customerId) {
                throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'No Stripe user data found and no custom ID provided');
            }
            pnid_1.PNID.updateOne({ pid: pnid.pid }, {
                $set: updateData
            }, { upsert: true }).exec();
        }
    }
    catch (error) {
        let message = 'Unknown Mongo error';
        if (error instanceof Error) {
            message = error.message;
        }
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, message);
    }
    return {};
}
exports.setStripeConnectionData = setStripeConnectionData;
