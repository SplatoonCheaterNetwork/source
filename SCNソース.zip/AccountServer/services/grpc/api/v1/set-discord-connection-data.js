"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setDiscordConnectionData = void 0;
const nice_grpc_1 = require("nice-grpc");
async function setDiscordConnectionData(request, context) {
    // * This is asserted in authentication-middleware, we know this is never null
    const pnid = context.pnid;
    try {
        pnid.connections.discord.id = request.id;
        await pnid.save();
    }
    catch (error) {
        let message = 'Unknown Mongo error';
        if (error instanceof Error) {
            message = error.message;
        }
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, message);
    }
    return {};
}
exports.setDiscordConnectionData = setDiscordConnectionData;
