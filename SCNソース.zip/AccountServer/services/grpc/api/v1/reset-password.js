"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resetPassword = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const nice_grpc_1 = require("nice-grpc");
const util_1 = require("../../../../util");
const database_1 = require("../../../../database");
// * This sucks
const PASSWORD_WORD_OR_NUMBER_REGEX = /(?=.*[a-zA-Z])(?=.*\d).*/;
const PASSWORD_WORD_OR_PUNCTUATION_REGEX = /(?=.*[a-zA-Z])(?=.*[_\-.]).*/;
const PASSWORD_NUMBER_OR_PUNCTUATION_REGEX = /(?=.*\d)(?=.*[_\-.]).*/;
const PASSWORD_REPEATED_CHARACTER_REGEX = /(.)\1\1/;
async function resetPassword(request) {
    const password = request.password.trim();
    const passwordConfirm = request.passwordConfirm.trim();
    const token = request.token.trim();
    if (!token) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Missing token');
    }
    let unpackedToken;
    try {
        const decryptedToken = await (0, util_1.decryptToken)(Buffer.from(token, 'base64'));
        unpackedToken = (0, util_1.unpackToken)(decryptedToken);
    }
    catch {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Invalid token');
    }
    if (unpackedToken.expire_time < Date.now()) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Token expired');
    }
    const pnid = await (0, database_1.getPNIDByPID)(unpackedToken.pid);
    if (!pnid) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Invalid token. No user found');
    }
    if (!password) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Must enter a password');
    }
    if (password.length < 6) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Password is too short');
    }
    if (password.length > 16) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Password is too long');
    }
    if (password.toLowerCase() === pnid.usernameLower) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Password cannot be the same as username');
    }
    if (!PASSWORD_WORD_OR_NUMBER_REGEX.test(password) && !PASSWORD_WORD_OR_PUNCTUATION_REGEX.test(password) && !PASSWORD_NUMBER_OR_PUNCTUATION_REGEX.test(password)) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Password must have combination of letters, numbers, and/or punctuation characters');
    }
    if (PASSWORD_REPEATED_CHARACTER_REGEX.test(password)) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Password may not have 3 repeating characters');
    }
    if (password !== passwordConfirm) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Passwords do not match');
    }
    const primaryPasswordHash = (0, util_1.nintendoPasswordHash)(password, pnid.pid);
    const passwordHash = await bcrypt_1.default.hash(primaryPasswordHash, 10);
    pnid.password = passwordHash;
    await pnid.save();
    return {};
}
exports.resetPassword = resetPassword;
