"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.forgotPassword = void 0;
const nice_grpc_1 = require("nice-grpc");
const validator_1 = __importDefault(require("validator"));
const database_1 = require("../../../../database");
const util_1 = require("../../../../util");
async function forgotPassword(request) {
    const input = request.emailAddressOrUsername.trim();
    if (!input) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Invalid or missing input');
    }
    let pnid;
    if (validator_1.default.isEmail(input)) {
        pnid = await (0, database_1.getPNIDByEmailAddress)(input);
    }
    else {
        pnid = await (0, database_1.getPNIDByUsername)(input);
    }
    if (pnid) {
        await (0, util_1.sendForgotPasswordEmail)(pnid);
    }
    return {};
}
exports.forgotPassword = forgotPassword;
