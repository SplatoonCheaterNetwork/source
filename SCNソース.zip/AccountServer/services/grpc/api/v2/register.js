"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.register = void 0;
const node_crypto_1 = __importDefault(require("node:crypto"));
const nice_grpc_1 = require("nice-grpc");
const email_validator_1 = __importDefault(require("email-validator"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const moment_1 = __importDefault(require("moment"));
const hcaptcha_1 = __importDefault(require("hcaptcha"));
const mii_js_1 = __importDefault(require("mii-js"));
const database_1 = require("../../../../database");
const util_1 = require("../../../../util");
const logger_1 = require("../../../../logger");
const pnid_1 = require("../../../../models/pnid");
const nex_account_1 = require("../../../../models/nex-account");
const config_manager_1 = require("../../../../config-manager");
const system_types_1 = require("../../../../types/common/system-types");
const token_types_1 = require("../../../../types/common/token-types");
const PNID_VALID_CHARACTERS_REGEX = /^[\w\-.]*$/;
const PNID_PUNCTUATION_START_REGEX = /^[_\-.]/;
const PNID_PUNCTUATION_END_REGEX = /[_\-.]$/;
const PNID_PUNCTUATION_DUPLICATE_REGEX = /[_\-.]{2,}/;
// * This sucks
const PASSWORD_WORD_OR_NUMBER_REGEX = /(?=.*[a-zA-Z])(?=.*\d).*/;
const PASSWORD_WORD_OR_PUNCTUATION_REGEX = /(?=.*[a-zA-Z])(?=.*[_\-.]).*/;
const PASSWORD_NUMBER_OR_PUNCTUATION_REGEX = /(?=.*\d)(?=.*[_\-.]).*/;
const PASSWORD_REPEATED_CHARACTER_REGEX = /(.)\1\1/;
const DEFAULT_MII_DATA = Buffer.from('AwAAQOlVognnx0GC2/uogAOzuI0n2QAAAEBEAGUAZgBhAHUAbAB0AAAAAAAAAEBAAAAhAQJoRBgmNEYUgRIXaA0AACkAUkhQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGm9', 'base64');
async function register(request) {
    const email = request.email?.trim();
    const username = request.username?.trim();
    const miiName = request.miiName?.trim();
    const password = request.password?.trim();
    const passwordConfirm = request.passwordConfirm?.trim();
    const captchaResponse = request.captchaResponse?.trim();
    // * Only validate the captcha if that's enabled
    if (!config_manager_1.disabledFeatures.captcha) {
        if (!captchaResponse) {
            throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Must fill in captcha');
        }
        const captchaVerify = await hcaptcha_1.default.verify(config_manager_1.config.hcaptcha.secret, captchaResponse);
        if (!captchaVerify.success) {
            throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Captcha verification failed');
        }
    }
    if (!email) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Must enter an email address');
    }
    if (!email_validator_1.default.validate(email)) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Invalid email address');
    }
    if (!username) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Must enter a username');
    }
    if (username.length < 6) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Username is too short');
    }
    if (username.length > 16) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Username is too long');
    }
    if (!PNID_VALID_CHARACTERS_REGEX.test(username)) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Username contains invalid characters');
    }
    if (PNID_PUNCTUATION_START_REGEX.test(username)) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Username cannot begin with punctuation characters');
    }
    if (PNID_PUNCTUATION_END_REGEX.test(username)) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Username cannot end with punctuation characters');
    }
    if (PNID_PUNCTUATION_DUPLICATE_REGEX.test(username)) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Two or more punctuation characters cannot be used in a row');
    }
    const userExists = await (0, database_1.doesPNIDExist)(username);
    if (userExists) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'PNID already in use');
    }
    if (!miiName) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Must enter a Mii name');
    }
    const miiNameBuffer = Buffer.from(miiName, 'utf16le'); // * UTF8 to UTF16
    if (miiNameBuffer.length > 0x14) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Mii name too long');
    }
    if (!password) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Must enter a password');
    }
    if (password.length < 6 || password.length > 16) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Password must be between 6 and 16 characters long');
    }
    if (password.toLowerCase() === username.toLowerCase()) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Password cannot be the same as username');
    }
    if (!PASSWORD_WORD_OR_NUMBER_REGEX.test(password) && !PASSWORD_WORD_OR_PUNCTUATION_REGEX.test(password) && !PASSWORD_NUMBER_OR_PUNCTUATION_REGEX.test(password)) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Password must have combination of letters, numbers, and/or punctuation characters');
    }
    if (PASSWORD_REPEATED_CHARACTER_REGEX.test(password)) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Password may not have 3 repeating characters');
    }
    if (password !== passwordConfirm) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Passwords do not match');
    }
    const mii = new mii_js_1.default(DEFAULT_MII_DATA);
    mii.miiName = miiName;
    const creationDate = (0, moment_1.default)().format('YYYY-MM-DDTHH:MM:SS');
    let pnid;
    let nexAccount;
    const session = await (0, database_1.connection)().startSession();
    await session.startTransaction();
    try {
        // * PNIDs can only be registered from a Wii U
        // * So assume website users are WiiU NEX accounts
        nexAccount = new nex_account_1.NEXAccount({
            device_type: 'wiiu'
        });
        await nexAccount.generatePID();
        await nexAccount.generatePassword();
        // * Quick hack to get the PIDs to match
        // TODO - Change this maybe?
        // * NN with a NNID will always use the NNID PID
        // * even if the provided NEX PID is different
        // * To fix this we make them the same PID
        nexAccount.owning_pid = nexAccount.pid;
        await nexAccount.save({ session });
        const primaryPasswordHash = (0, util_1.nintendoPasswordHash)(password, nexAccount.pid);
        const passwordHash = await bcrypt_1.default.hash(primaryPasswordHash, 10);
        pnid = new pnid_1.PNID({
            pid: nexAccount.pid,
            creation_date: creationDate,
            updated: creationDate,
            username: username,
            usernameLower: username.toLowerCase(),
            password: passwordHash,
            birthdate: '1990-01-01',
            gender: 'M',
            country: 'US',
            language: 'en',
            email: {
                address: email.toLowerCase(),
                primary: true,
                parent: true,
                reachable: false,
                validated: false,
                id: node_crypto_1.default.randomBytes(4).readUInt32LE()
            },
            region: 0x310B0000,
            timezone: {
                name: 'America/New_York',
                offset: -14400 // TODO - Change this
            },
            mii: {
                name: miiName,
                primary: true,
                data: mii.encode().toString('base64'),
                id: node_crypto_1.default.randomBytes(4).readUInt32LE(),
                hash: node_crypto_1.default.randomBytes(7).toString('hex'),
                image_url: '',
                image_id: node_crypto_1.default.randomBytes(4).readUInt32LE()
            },
            flags: {
                active: true,
                marketing: true,
                off_device: true // TODO - Change this
            },
            identification: {
                email_code: 1,
                email_token: '' // * will be overwritten before saving
            }
        });
        await pnid.generateEmailValidationCode();
        await pnid.generateEmailValidationToken();
        await pnid.generateMiiImages();
        await pnid.save({ session });
        await session.commitTransaction();
    }
    catch (error) {
        let message = 'Unknown Mongo error';
        if (error instanceof Error) {
            message = error.message;
        }
        (0, logger_1.LOG_ERROR)(`[gRPC] /api.API/Register: ${message}`);
        await session.abortTransaction();
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, message);
    }
    finally {
        // * This runs regardless of failure
        // * Returning on catch will not prevent this from running
        await session.endSession();
    }
    await (0, util_1.sendConfirmationEmail)(pnid);
    const accessTokenOptions = {
        system_type: system_types_1.SystemType.API,
        token_type: token_types_1.TokenType.OAuthAccess,
        pid: pnid.pid,
        access_level: pnid.access_level,
        title_id: BigInt(0),
        expire_time: BigInt(Date.now() + (3600 * 1000))
    };
    const refreshTokenOptions = {
        system_type: system_types_1.SystemType.API,
        token_type: token_types_1.TokenType.OAuthRefresh,
        pid: pnid.pid,
        access_level: pnid.access_level,
        title_id: BigInt(0),
        expire_time: BigInt(Date.now() + 12 * 3600 * 1000)
    };
    const accessTokenBuffer = await (0, util_1.generateToken)(config_manager_1.config.aes_key, accessTokenOptions);
    const refreshTokenBuffer = await (0, util_1.generateToken)(config_manager_1.config.aes_key, refreshTokenOptions);
    if (!accessTokenBuffer) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INTERNAL, 'Failed to generate access token');
    }
    if (!refreshTokenBuffer) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INTERNAL, 'Failed to generate refresh token');
    }
    return {
        accessToken: accessTokenBuffer.toString('hex'),
        tokenType: 'Bearer',
        expiresIn: 3600,
        refreshToken: refreshTokenBuffer.toString('hex')
    };
}
exports.register = register;
