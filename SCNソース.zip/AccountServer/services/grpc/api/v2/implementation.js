"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.apiServiceImplementationV2 = void 0;
const register_1 = require("../../../../services/grpc/api/v2/register");
const login_1 = require("../../../../services/grpc/api/v2/login");
const get_user_data_1 = require("../../../../services/grpc/api/v2/get-user-data");
const update_user_data_1 = require("../../../../services/grpc/api/v2/update-user-data");
const forgot_password_1 = require("../../../../services/grpc/api/v2/forgot-password");
const reset_password_1 = require("../../../../services/grpc/api/v2/reset-password");
const set_discord_connection_data_1 = require("../../../../services/grpc/api/v2/set-discord-connection-data");
const set_stripe_connection_data_1 = require("../../../../services/grpc/api/v2/set-stripe-connection-data");
exports.apiServiceImplementationV2 = {
    register: register_1.register,
    login: login_1.login,
    getUserData: get_user_data_1.getUserData,
    updateUserData: update_user_data_1.updateUserData,
    forgotPassword: forgot_password_1.forgotPassword,
    resetPassword: reset_password_1.resetPassword,
    setDiscordConnectionData: set_discord_connection_data_1.setDiscordConnectionData,
    setStripeConnectionData: set_stripe_connection_data_1.setStripeConnectionData
};
