"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.login = void 0;
const nice_grpc_1 = require("nice-grpc");
const bcrypt_1 = __importDefault(require("bcrypt"));
const database_1 = require("../../../../database");
const util_1 = require("../../../../util");
const config_manager_1 = require("../../../../config-manager");
const system_types_1 = require("../../../../types/common/system-types");
const token_types_1 = require("../../../../types/common/token-types");
async function login(request) {
    const grantType = request.grantType?.trim();
    const username = request.username?.trim();
    const password = request.password?.trim();
    const refreshToken = request.refreshToken?.trim();
    if (!['password', 'refresh_token'].includes(grantType)) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Invalid grant type');
    }
    if (grantType === 'password' && !username) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Invalid or missing username');
    }
    if (grantType === 'password' && !password) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Invalid or missing password');
    }
    if (grantType === 'refresh_token' && !refreshToken) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Invalid or missing refresh token');
    }
    let pnid;
    if (grantType === 'password') {
        pnid = await (0, database_1.getPNIDByUsername)(username); // * We know username will never be null here
        if (!pnid) {
            throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'User not found');
        }
        const hashedPassword = (0, util_1.nintendoPasswordHash)(password, pnid.pid); // * We know password will never be null here
        if (!bcrypt_1.default.compareSync(hashedPassword, pnid.password)) {
            throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Password is incorrect');
        }
    }
    else {
        pnid = await (0, database_1.getPNIDByAPIRefreshToken)(refreshToken); // * We know refreshToken will never be null here
        if (!pnid) {
            throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'Invalid or missing refresh token');
        }
    }
    if (pnid.deleted) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.UNAUTHENTICATED, 'Account has been deleted');
    }
    const accessTokenOptions = {
        system_type: system_types_1.SystemType.API,
        token_type: token_types_1.TokenType.OAuthAccess,
        pid: pnid.pid,
        access_level: pnid.access_level,
        title_id: BigInt(0),
        expire_time: BigInt(Date.now() + (3600 * 1000))
    };
    const refreshTokenOptions = {
        system_type: system_types_1.SystemType.API,
        token_type: token_types_1.TokenType.OAuthAccess,
        pid: pnid.pid,
        access_level: pnid.access_level,
        title_id: BigInt(0),
        expire_time: BigInt(Date.now() + 12 * 3600 * 1000)
    };
    const accessTokenBuffer = await (0, util_1.generateToken)(config_manager_1.config.aes_key, accessTokenOptions);
    const refreshTokenBuffer = await (0, util_1.generateToken)(config_manager_1.config.aes_key, refreshTokenOptions);
    if (!accessTokenBuffer) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INTERNAL, 'Failed to generate access token');
    }
    if (!refreshTokenBuffer) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INTERNAL, 'Failed to generate refresh token');
    }
    return {
        accessToken: accessTokenBuffer.toString('hex'),
        tokenType: 'Bearer',
        expiresIn: 3600,
        refreshToken: refreshTokenBuffer.toString('hex')
    };
}
exports.login = login;
