"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserData = void 0;
const nice_grpc_1 = require("nice-grpc");
const database_1 = require("../../../../database");
const permission_flags_1 = require("../../../../types/common/permission-flags");
const config_manager_1 = require("../../../../config-manager");
const device_1 = require("../../../../models/device");
async function getUserData(request) {
    const pnid = await (0, database_1.getPNIDByPID)(request.pid);
    if (!pnid) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'No PNID found');
    }
    const devices = (await device_1.Device.find({
        linked_pids: pnid.pid
    })).map((device) => {
        return {
            model: device.get('model'),
            serial: device.serial,
            linkedPids: device.linked_pids,
            accessLevel: device.access_level,
            serverAccessLevel: device.server_access_level
        };
    });
    return {
        deleted: pnid.deleted,
        pid: pnid.pid,
        username: pnid.username,
        accessLevel: pnid.access_level,
        serverAccessLevel: pnid.server_access_level,
        mii: {
            name: pnid.mii.name,
            data: pnid.mii.data,
            url: `${config_manager_1.config.cdn.base_url}/mii/${pnid.pid}/standard.tga`
        },
        creationDate: pnid.creation_date,
        birthdate: pnid.birthdate,
        gender: pnid.gender,
        country: pnid.country,
        language: pnid.language,
        emailAddress: pnid.email.address,
        tierName: pnid.connections.stripe.tier_name,
        permissions: {
            bannedAllPermanently: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.BANNED_ALL_PERMANENTLY),
            bannedAllTemporarily: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.BANNED_ALL_TEMPORARILY),
            betaAccess: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.BETA_ACCESS),
            accessAdminPanel: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.ACCESS_ADMIN_PANEL),
            createServerConfigs: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.CREATE_SERVER_CONFIGS),
            modifyServerConfigs: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.MODIFY_SERVER_CONFIGS),
            deployServer: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.DEPLOY_SERVER),
            modifyPnids: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.MODIFY_PNIDS),
            modifyNexAccounts: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.MODIFY_NEX_ACCOUNTS),
            modifyConsoles: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.MODIFY_CONSOLES),
            banPnids: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.BAN_PNIDS),
            banNexAccounts: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.BAN_NEX_ACCOUNTS),
            banConsoles: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.BAN_CONSOLES),
            moderateMiiverse: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.MODERATE_MIIVERSE),
            createApiKeys: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.CREATE_API_KEYS),
            createBossTasks: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.CREATE_BOSS_TASKS),
            updateBossTasks: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.UPDATE_BOSS_TASKS),
            deleteBossTasks: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.DELETE_BOSS_TASKS),
            uploadBossFiles: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.UPLOAD_BOSS_FILES),
            updateBossFiles: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.UPDATE_BOSS_FILES),
            deleteBossFiles: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.DELETE_BOSS_FILES),
            updatePnidPermissions: pnid.hasPermission(permission_flags_1.PNID_PERMISSION_FLAGS.UPDATE_PNID_PERMISSIONS)
        },
        linkedDevices: devices
    };
}
exports.getUserData = getUserData;
