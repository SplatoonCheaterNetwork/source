"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.accountServiceImplementationV2 = void 0;
const get_user_data_1 = require("../../../../services/grpc/account/v2/get-user-data");
const get_nex_password_1 = require("../../../../services/grpc/account/v2/get-nex-password");
const get_nex_data_1 = require("../../../../services/grpc/account/v2/get-nex-data");
const update_pnid_permissions_1 = require("../../../../services/grpc/account/v2/update-pnid-permissions");
const exchange_token_for_user_data_1 = require("../../../../services/grpc/account/v2/exchange-token-for-user-data");
exports.accountServiceImplementationV2 = {
    getUserData: get_user_data_1.getUserData,
    getNEXPassword: get_nex_password_1.getNEXPassword,
    getNEXData: get_nex_data_1.getNEXData,
    updatePNIDPermissions: update_pnid_permissions_1.updatePNIDPermissions,
    exchangeTokenForUserData: exchange_token_for_user_data_1.exchangeTokenForUserData
};
