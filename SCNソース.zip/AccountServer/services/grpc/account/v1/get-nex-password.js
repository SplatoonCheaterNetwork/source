"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getNEXPassword = void 0;
const nice_grpc_1 = require("nice-grpc");
const nex_account_1 = require("../../../../models/nex-account");
async function getNEXPassword(request) {
    const nexAccount = await nex_account_1.NEXAccount.findOne({ pid: request.pid });
    if (!nexAccount) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'No NEX account found');
    }
    return {
        password: nexAccount.password
    };
}
exports.getNEXPassword = getNEXPassword;
