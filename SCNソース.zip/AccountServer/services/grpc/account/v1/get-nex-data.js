"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getNEXData = void 0;
const nice_grpc_1 = require("nice-grpc");
const nex_account_1 = require("../../../../models/nex-account");
async function getNEXData(request) {
    const nexAccount = await nex_account_1.NEXAccount.findOne({ pid: request.pid });
    if (!nexAccount) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.INVALID_ARGUMENT, 'No NEX account found');
    }
    return {
        pid: nexAccount.pid,
        password: nexAccount.password,
        owningPid: nexAccount.owning_pid,
        accessLevel: nexAccount.access_level,
        serverAccessLevel: nexAccount.server_access_level,
        friendCode: nexAccount.friend_code
    };
}
exports.getNEXData = getNEXData;
