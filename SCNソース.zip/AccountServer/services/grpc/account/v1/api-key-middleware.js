"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.apiKeyMiddleware = void 0;
const nice_grpc_1 = require("nice-grpc");
const config_manager_1 = require("../../../../config-manager");
async function* apiKeyMiddleware(call, context) {
    const apiKey = context.metadata.get('X-API-Key');
    if (!apiKey || apiKey !== config_manager_1.config.grpc.master_api_keys.account) {
        throw new nice_grpc_1.ServerError(nice_grpc_1.Status.UNAUTHENTICATED, 'Missing or invalid API key');
    }
    return yield* call.next(call.request, context);
}
exports.apiKeyMiddleware = apiKeyMiddleware;
