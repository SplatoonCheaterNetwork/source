"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapToObject = exports.getValueFromHeaders = exports.getValueFromQueryString = exports.makeSafeQs = exports.sendPNIDDeletedEmail = exports.sendForgotPasswordEmail = exports.sendEmailConfirmedParentalControlsEmail = exports.sendEmailConfirmedEmail = exports.sendConfirmationEmail = exports.nascError = exports.nascDateTime = exports.writeLocalCDNFile = exports.uploadCDNAsset = exports.fullUrl = exports.unpackToken = exports.decryptToken = exports.generateToken = exports.nintendoBase64Encode = exports.nintendoBase64Decode = exports.nintendoPasswordHash = void 0;
const node_crypto_1 = __importDefault(require("node:crypto"));
const node_path_1 = __importDefault(require("node:path"));
const client_s3_1 = require("@aws-sdk/client-s3");
const fs_extra_1 = __importDefault(require("fs-extra"));
const buffer_crc32_1 = __importDefault(require("buffer-crc32"));
const crc_1 = require("crc");
const mailer_1 = require("./mailer");
const system_types_1 = require("./types/common/system-types");
const token_types_1 = require("./types/common/token-types");
const config_manager_1 = require("./config-manager");
let s3;
if (!config_manager_1.disabledFeatures.s3) {
    s3 = new client_s3_1.S3({
        endpoint: config_manager_1.config.s3.endpoint,
        forcePathStyle: config_manager_1.config.s3.forcePathStyle,
        region: config_manager_1.config.s3.region,
        credentials: {
            accessKeyId: config_manager_1.config.s3.key,
            secretAccessKey: config_manager_1.config.s3.secret
        }
    });
}
function nintendoPasswordHash(password, pid) {
    const pidBuffer = Buffer.alloc(4);
    pidBuffer.writeUInt32LE(pid);
    const unpacked = Buffer.concat([
        pidBuffer,
        Buffer.from('\x02\x65\x43\x46'),
        Buffer.from(password)
    ]);
    return node_crypto_1.default.createHash('sha256').update(unpacked).digest().toString('hex');
}
exports.nintendoPasswordHash = nintendoPasswordHash;
function nintendoBase64Decode(encoded) {
    encoded = encoded.replaceAll('.', '+').replaceAll('-', '/').replaceAll('*', '=');
    return Buffer.from(encoded, 'base64');
}
exports.nintendoBase64Decode = nintendoBase64Decode;
function nintendoBase64Encode(decoded) {
    const encoded = Buffer.from(decoded).toString('base64');
    return encoded.replaceAll('+', '.').replaceAll('/', '-').replaceAll('=', '*');
}
exports.nintendoBase64Encode = nintendoBase64Encode;
function generateToken(key, options) {
    let dataBuffer = Buffer.alloc(1 + 1 + 4 + 8);
    dataBuffer.writeUInt8(options.system_type, 0x0);
    dataBuffer.writeUInt8(options.token_type, 0x1);
    dataBuffer.writeUInt32LE(options.pid, 0x2);
    dataBuffer.writeBigUInt64LE(options.expire_time, 0x6);
    if ((options.token_type !== token_types_1.TokenType.OAuthAccess && options.token_type !== token_types_1.TokenType.OAuthRefresh) || options.system_type === system_types_1.SystemType.API) {
        // * Access and refresh tokens have smaller bodies due to size constraints
        // * The API does not have this restraint, however
        if (options.title_id === undefined || options.access_level === undefined) {
            return null;
        }
        dataBuffer = Buffer.concat([
            dataBuffer,
            Buffer.alloc(8 + 1)
        ]);
        dataBuffer.writeBigUInt64LE(options.title_id, 0xE);
        dataBuffer.writeInt8(options.access_level, 0x16);
    }
    const iv = Buffer.alloc(16);
    const cipher = node_crypto_1.default.createCipheriv('aes-256-cbc', Buffer.from(key, 'hex'), iv);
    const encrypted = Buffer.concat([
        cipher.update(dataBuffer),
        cipher.final()
    ]);
    let final = encrypted;
    if ((options.token_type !== token_types_1.TokenType.OAuthAccess && options.token_type !== token_types_1.TokenType.OAuthRefresh) || options.system_type === system_types_1.SystemType.API) {
        // * Access and refresh tokens don't get a checksum due to size constraints
        const checksum = (0, buffer_crc32_1.default)(dataBuffer);
        final = Buffer.concat([
            checksum,
            final
        ]);
    }
    return final;
}
exports.generateToken = generateToken;
function decryptToken(token, key) {
    let encryptedBody;
    let expectedChecksum = 0;
    if (token.length === 16) {
        // * Token is an access/refresh token, no checksum
        encryptedBody = token;
    }
    else {
        expectedChecksum = token.readUint32BE();
        encryptedBody = token.subarray(4);
    }
    if (!key) {
        key = config_manager_1.config.aes_key;
    }
    const iv = Buffer.alloc(16);
    const decipher = node_crypto_1.default.createDecipheriv('aes-256-cbc', Buffer.from(key, 'hex'), iv);
    const decrypted = Buffer.concat([
        decipher.update(encryptedBody),
        decipher.final()
    ]);
    if (expectedChecksum && (expectedChecksum !== (0, crc_1.crc32)(decrypted))) {
        throw new Error('Checksum did not match. Failed decrypt. Are you using the right key?');
    }
    return decrypted;
}
exports.decryptToken = decryptToken;
function unpackToken(token) {
    const unpacked = {
        system_type: token.readUInt8(0x0),
        token_type: token.readUInt8(0x1),
        pid: token.readUInt32LE(0x2),
        expire_time: token.readBigUInt64LE(0x6)
    };
    if (unpacked.token_type !== token_types_1.TokenType.OAuthAccess && unpacked.token_type !== token_types_1.TokenType.OAuthRefresh) {
        unpacked.title_id = token.readBigUInt64LE(0xE);
        unpacked.access_level = token.readInt8(0x16);
    }
    return unpacked;
}
exports.unpackToken = unpackToken;
function fullUrl(request) {
    const protocol = request.protocol;
    const host = request.host;
    const opath = request.originalUrl;
    return `${protocol}://${host}${opath}`;
}
exports.fullUrl = fullUrl;
async function uploadCDNAsset(bucket, key, data, acl) {
    if (config_manager_1.disabledFeatures.s3) {
        await writeLocalCDNFile(key, data);
    }
    else {
        await s3.putObject({
            Body: data,
            Key: key,
            Bucket: bucket,
            ACL: acl
        });
    }
}
exports.uploadCDNAsset = uploadCDNAsset;
async function writeLocalCDNFile(key, data) {
    const filePath = config_manager_1.config.cdn.disk_path;
    const folder = node_path_1.default.dirname(filePath);
    await fs_extra_1.default.ensureDir(folder);
    await fs_extra_1.default.writeFile(filePath, data);
}
exports.writeLocalCDNFile = writeLocalCDNFile;
function nascDateTime() {
    const now = new Date();
    const year = now.getFullYear();
    const month = (now.getMonth() + 1).toString().padStart(2, '0'); // * Months are zero-based
    const day = now.getDate().toString().padStart(2, '0');
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    return `${year}${month}${day}${hours}${minutes}${seconds}`;
}
exports.nascDateTime = nascDateTime;
function nascError(errorCode) {
    return new URLSearchParams({
        retry: nintendoBase64Encode('1'),
        returncd: errorCode == 'null' ? errorCode : nintendoBase64Encode(errorCode),
        datetime: nintendoBase64Encode(nascDateTime())
    });
}
exports.nascError = nascError;
async function sendConfirmationEmail(pnid) {
    const options = {
        to: pnid.email.address,
        subject: '[Pretendo Network] Please confirm your email address',
        username: pnid.username,
        confirmation: {
            href: `https://api.scn.cc/v1/email/verify?token=${pnid.identification.email_token}`,
            code: pnid.identification.email_code
        },
        text: `Hello ${pnid.username}! \r\n\r\nYour Pretendo Network ID activation is almost complete. Please click the link to confirm your e-mail address and complete the activation process: \r\nhttps://api.scn.cc/v1/email/verify?token=${pnid.identification.email_token} \r\n\r\nYou may also enter the following 6-digit code on your console: ${pnid.identification.email_code}`
    };
    await (0, mailer_1.sendMail)(options);
}
exports.sendConfirmationEmail = sendConfirmationEmail;
async function sendEmailConfirmedEmail(pnid) {
    const options = {
        to: pnid.email.address,
        subject: '[Pretendo Network] Email address confirmed',
        username: pnid.username,
        paragraph: 'your email address has been confirmed. We hope you have fun on Pretendo Network!',
        text: `Dear ${pnid.username}, \r\n\r\nYour email address has been confirmed. We hope you have fun on Pretendo Network!`
    };
    await (0, mailer_1.sendMail)(options);
}
exports.sendEmailConfirmedEmail = sendEmailConfirmedEmail;
async function sendEmailConfirmedParentalControlsEmail(pnid) {
    const options = {
        to: pnid.email.address,
        subject: '[Pretendo Network] Email address confirmed for Parental Controls',
        username: pnid.username,
        paragraph: 'your email address has been confirmed for use with Parental Controls.',
        text: `Dear ${pnid.username}, \r\n\r\nYour email address has been confirmed for use with Parental Controls.`
    };
    await (0, mailer_1.sendMail)(options);
}
exports.sendEmailConfirmedParentalControlsEmail = sendEmailConfirmedParentalControlsEmail;
async function sendForgotPasswordEmail(pnid) {
    const tokenOptions = {
        system_type: system_types_1.SystemType.PasswordReset,
        token_type: token_types_1.TokenType.PasswordReset,
        pid: pnid.pid,
        access_level: pnid.access_level,
        title_id: BigInt(0),
        expire_time: BigInt(Date.now() + (24 * 60 * 60 * 1000)) // * Only valid for 24 hours
    };
    const tokenBuffer = await generateToken(config_manager_1.config.aes_key, tokenOptions);
    const passwordResetToken = tokenBuffer ? tokenBuffer.toString('hex') : '';
    // TODO - Handle null token
    const mailerOptions = {
        to: pnid.email.address,
        subject: '[Pretendo Network] Forgot Password',
        username: pnid.username,
        paragraph: 'a password reset has been requested from this account. If you did not request the password reset, please ignore this email. If you did request this password reset, please click the link below to reset your password.',
        link: {
            text: 'Reset password',
            href: `${config_manager_1.config.website_base}/account/reset-password?token=${encodeURIComponent(passwordResetToken)}`
        },
        text: `Dear ${pnid.username}, a password reset has been requested from this account. \r\n\r\nIf you did not request the password reset, please ignore this email. \r\nIf you did request this password reset, please click the link to reset your password: ${config_manager_1.config.website_base}/account/reset-password?token=${encodeURIComponent(passwordResetToken)}`
    };
    await (0, mailer_1.sendMail)(mailerOptions);
}
exports.sendForgotPasswordEmail = sendForgotPasswordEmail;
async function sendPNIDDeletedEmail(email, username) {
    const options = {
        to: email,
        subject: '[Pretendo Network] PNID Deleted',
        username: username,
        link: {
            text: 'Discord Server',
            href: 'https://discord.com/invite/pretendo'
        },
        text: `Your PNID ${username} has successfully been deleted. If you had a tier subscription, a separate cancellation email will be sent. If you do not receive this cancellation email, or your subscription is still being charged, please contact @jon on our Discord server`
    };
    await (0, mailer_1.sendMail)(options);
}
exports.sendPNIDDeletedEmail = sendPNIDDeletedEmail;
function makeSafeQs(query) {
    const entries = Object.entries(query);
    const output = {};
    for (const [key, value] of entries) {
        if (typeof value !== 'string') {
            // * ignore non-strings
            continue;
        }
        output[key] = value;
    }
    return output;
}
exports.makeSafeQs = makeSafeQs;
function getValueFromQueryString(qs, key) {
    let property = qs[key];
    let value;
    if (property) {
        if (Array.isArray(property)) {
            property = property[0];
        }
        if (typeof property !== 'string') {
            property = makeSafeQs(property);
            value = property[key];
        }
        else {
            value = property;
        }
    }
    return value;
}
exports.getValueFromQueryString = getValueFromQueryString;
function getValueFromHeaders(headers, key) {
    let header = headers[key];
    let value;
    if (header) {
        if (!Array.isArray(header)) {
            header = header.split(', ');
        }
        value = header[0];
    }
    return value;
}
exports.getValueFromHeaders = getValueFromHeaders;
function mapToObject(map) {
    return Object.fromEntries(Array.from(map.entries(), ([k, v]) => v instanceof Map ? [k, mapToObject(v)] : [k, v]));
}
exports.mapToObject = mapToObject;
