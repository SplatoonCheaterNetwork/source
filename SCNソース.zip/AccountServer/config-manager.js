"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = exports.disabledFeatures = void 0;
const fs_extra_1 = __importDefault(require("fs-extra"));
const dotenv_1 = __importDefault(require("dotenv"));
const is_valid_hostname_1 = __importDefault(require("is-valid-hostname"));
const logger_1 = require("./logger");
const config_1 = require("./types/common/config");
dotenv_1.default.config();
exports.disabledFeatures = {
    redis: false,
    email: false,
    captcha: false,
    s3: false,
    datastore: false
};
const hexadecimalStringRegex = /^[0-9a-f]+$/i;
(0, logger_1.LOG_INFO)('Loading config');
let mongooseConnectOptions = {};
if (process.env.PN_ACT_CONFIG_MONGOOSE_CONNECT_OPTIONS_PATH) {
    mongooseConnectOptions = fs_extra_1.default.readJSONSync(process.env.PN_ACT_CONFIG_MONGOOSE_CONNECT_OPTIONS_PATH);
}
if (process.env.PN_ACT_CONFIG_EMAIL_SECURE) {
    if (process.env.PN_ACT_CONFIG_EMAIL_SECURE !== 'true' && process.env.PN_ACT_CONFIG_EMAIL_SECURE !== 'false') {
        (0, logger_1.LOG_ERROR)(`PN_ACT_CONFIG_EMAIL_SECURE must be either true or false, got ${process.env.PN_ACT_CONFIG_EMAIL_SECURE}`);
        process.exit(0);
    }
}
exports.config = {
    http: {
        port: Number(process.env.PN_ACT_CONFIG_HTTP_PORT || '')
    },
    mongoose: {
        connection_string: process.env.PN_ACT_CONFIG_MONGO_CONNECTION_STRING || '',
        options: mongooseConnectOptions
    },
    redis: {
        client: {
            url: process.env.PN_ACT_CONFIG_REDIS_URL || ''
        }
    },
    email: {
        ses: {
            region: process.env.PN_ACT_CONFIG_EMAIL_SES_REGION || '',
            key: process.env.PN_ACT_CONFIG_EMAIL_SES_ACCESS_KEY || '',
            secret: process.env.PN_ACT_CONFIG_EMAIL_SES_SECRET_KEY || ''
        },
        from: process.env.PN_ACT_CONFIG_EMAIL_FROM || ''
    },
    s3: {
        bucket: process.env.PN_ACT_CONFIG_S3_BUCKET || '',
        endpoint: process.env.PN_ACT_CONFIG_S3_ENDPOINT || '',
        key: process.env.PN_ACT_CONFIG_S3_ACCESS_KEY || '',
        secret: process.env.PN_ACT_CONFIG_S3_ACCESS_SECRET || '',
        region: process.env.PN_ACT_CONFIG_S3_REGION || '',
        forcePathStyle: process.env.PN_ACT_CONFIG_S3_FORCE_PATH_STYLE === 'true'
    },
    hcaptcha: {
        secret: process.env.PN_ACT_CONFIG_HCAPTCHA_SECRET || ''
    },
    cdn: {
        subdomain: process.env.PN_ACT_CONFIG_CDN_SUBDOMAIN,
        disk_path: process.env.PN_ACT_CONFIG_CDN_DISK_PATH || '',
        base_url: process.env.PN_ACT_CONFIG_CDN_BASE_URL || ''
    },
    website_base: process.env.PN_ACT_CONFIG_WEBSITE_BASE || '',
    aes_key: process.env.PN_ACT_CONFIG_AES_KEY || '',
    grpc: {
        master_api_keys: {
            account: process.env.PN_ACT_CONFIG_GRPC_MASTER_API_KEY_ACCOUNT || '',
            api: process.env.PN_ACT_CONFIG_GRPC_MASTER_API_KEY_API || ''
        },
        port: Number(process.env.PN_ACT_CONFIG_GRPC_PORT || '')
    },
    server_environment: process.env.PN_ACT_CONFIG_SERVER_ENVIRONMENT || '',
    datastore: {
        signature_secret: process.env.PN_ACT_CONFIG_DATASTORE_SIGNATURE_SECRET || ''
    },
    domains: {
        api: (process.env.PN_ACT_CONFIG_DOMAINS_API || 'api.scn.cc').split(','),
        assets: (process.env.PN_ACT_CONFIG_DOMAINS_ASSETS || 'assets.scn.cc').split(','),
        cbvc: (process.env.PN_ACT_CONFIG_DOMAINS_CBVC || 'cbvc.cdn.scn.cc').split(','),
        conntest: (process.env.PN_ACT_CONFIG_DOMAINS_CONNTEST || 'conntest.scn.cc').split(','),
        datastore: (process.env.PN_ACT_CONFIG_DOMAINS_DATASTORE || 'datastore.scn.cc').split(','),
        local_cdn: (process.env.PN_ACT_CONFIG_DOMAINS_LOCAL_CDN || '').split(','),
        nasc: (process.env.PN_ACT_CONFIG_DOMAINS_NASC || 'nasc.scn.cc').split(','),
        nnas: (process.env.PN_ACT_CONFIG_DOMAINS_NNAS || 'c.account.scn.cc,account.scn.cc').split(',')
    }
};
if (process.env.PN_ACT_CONFIG_STRIPE_SECRET_KEY) {
    exports.config.stripe = {
        secret_key: process.env.PN_ACT_CONFIG_STRIPE_SECRET_KEY
    };
}
// * Add the old config option for backwards compatibility
if (exports.config.cdn.subdomain) {
    exports.config.domains.local_cdn.push(exports.config.cdn.subdomain);
}
let configValid = true;
(0, logger_1.LOG_INFO)('Config loaded, checking integrity');
for (const service of config_1.domainServices) {
    const validDomains = [];
    const invalidDomains = [];
    const uniqueDomains = [...new Set(exports.config.domains[service])];
    for (const domain of uniqueDomains) {
        if ((0, is_valid_hostname_1.default)(domain)) {
            validDomains.push(domain);
        }
        else {
            invalidDomains.push(domain);
        }
    }
    if (validDomains.length === 0 && !config_1.optionalDomainServices.includes(service)) {
        (0, logger_1.LOG_ERROR)(`No valid domains found for ${service}. Set the PN_ACT_CONFIG_DOMAINS_${service.toUpperCase()} environment variable to a valid domain`);
        configValid = false;
    }
    if (invalidDomains.length) {
        (0, logger_1.LOG_WARN)(`Invalid domain(s) skipped for ${service}: ${(0, logger_1.formatHostnames)(invalidDomains)}`);
    }
    exports.config.domains[service] = validDomains;
}
if (!exports.config.http.port) {
    (0, logger_1.LOG_ERROR)('Failed to find HTTP port. Set the PN_ACT_CONFIG_HTTP_PORT environment variable');
    configValid = false;
}
if (!exports.config.mongoose.connection_string) {
    (0, logger_1.LOG_ERROR)('Failed to find MongoDB connection string. Set the PN_ACT_CONFIG_MONGO_CONNECTION_STRING environment variable');
    configValid = false;
}
if (!exports.config.cdn.base_url) {
    (0, logger_1.LOG_ERROR)('Failed to find asset CDN base URL. Set the PN_ACT_CONFIG_CDN_BASE_URL environment variable');
    configValid = false;
}
if (!exports.config.redis.client.url) {
    (0, logger_1.LOG_WARN)('Failed to find Redis connection url. Disabling feature and using in-memory cache. To enable feature set the PN_ACT_CONFIG_REDIS_URL environment variable');
    exports.disabledFeatures.redis = true;
}
if (!exports.config.email.ses.region) {
    (0, logger_1.LOG_WARN)('Failed to find AWS SES region. Disabling feature. To enable feature set the PN_ACT_CONFIG_EMAIL_SES_REGION environment variable');
    exports.disabledFeatures.email = true;
}
if (!exports.config.email.ses.key) {
    (0, logger_1.LOG_WARN)('Failed to find AWS SES access key. Disabling feature. To enable feature set the PN_ACT_CONFIG_EMAIL_SES_ACCESS_KEY environment variable');
    exports.disabledFeatures.email = true;
}
if (!exports.config.email.ses.secret) {
    (0, logger_1.LOG_WARN)('Failed to find AWS SES secret key. Disabling feature. To enable feature set the PN_ACT_CONFIG_EMAIL_SES_SECRET_KEY environment variable');
    exports.disabledFeatures.email = true;
}
if (!exports.config.email.from) {
    (0, logger_1.LOG_WARN)('Failed to find email from config. Disabling feature. To enable feature set the PN_ACT_CONFIG_EMAIL_FROM environment variable');
    exports.disabledFeatures.email = true;
}
if (!exports.disabledFeatures.email) {
    if (!exports.config.website_base) {
        (0, logger_1.LOG_ERROR)('Email sending is enabled and no website base was configured. Set the PN_ACT_CONFIG_WEBSITE_BASE environment variable');
        configValid = false;
    }
}
if (!exports.config.hcaptcha.secret) {
    (0, logger_1.LOG_WARN)('Failed to find captcha secret config. Disabling feature. To enable feature set the PN_ACT_CONFIG_HCAPTCHA_SECRET environment variable');
    exports.disabledFeatures.captcha = true;
}
if (!exports.config.s3.bucket) {
    (0, logger_1.LOG_WARN)('Failed to find S3 bucket config. Disabling feature. To enable feature set the PN_ACT_CONFIG_S3_BUCKET environment variable');
    exports.disabledFeatures.s3 = true;
}
if (!exports.config.s3.endpoint) {
    (0, logger_1.LOG_WARN)('Failed to find S3 endpoint config. Disabling feature. To enable feature set the PN_ACT_CONFIG_S3_ENDPOINT environment variable');
    exports.disabledFeatures.s3 = true;
}
if (!exports.config.s3.key) {
    (0, logger_1.LOG_WARN)('Failed to find S3 access key config. Disabling feature. To enable feature set the PN_ACT_CONFIG_S3_ACCESS_KEY environment variable');
    exports.disabledFeatures.s3 = true;
}
if (!exports.config.s3.secret) {
    (0, logger_1.LOG_WARN)('Failed to find S3 secret key config. Disabling feature. To enable feature set the PN_ACT_CONFIG_S3_ACCESS_SECRET environment variable');
    exports.disabledFeatures.s3 = true;
}
if (!exports.config.s3.region) {
    (0, logger_1.LOG_WARN)('Failed to find S3 region config. Disabling feature. To enable feature set the PN_ACT_CONFIG_S3_REGION environment variable');
    exports.disabledFeatures.s3 = true;
}
if (!exports.config.server_environment) {
    (0, logger_1.LOG_WARN)('Failed to find server environment. To change the environment, set the PN_ACT_CONFIG_SERVER_ENVIRONMENT environment variable. Defaulting to prod');
    exports.config.server_environment = 'prod';
}
if (exports.disabledFeatures.s3) {
    if (exports.config.domains.local_cdn.length === 0) {
        (0, logger_1.LOG_ERROR)('S3 file storage is disabled and no CDN domain was set. Set the PN_ACT_CONFIG_DOMAINS_LOCAL_CDN environment variable');
        configValid = false;
    }
    if (!exports.config.cdn.disk_path) {
        (0, logger_1.LOG_ERROR)('S3 file storage is disabled and no CDN disk path was set. Set the PN_ACT_CONFIG_CDN_DISK_PATH environment variable');
        configValid = false;
    }
    if (configValid) {
        (0, logger_1.LOG_WARN)(`S3 file storage disabled. Using disk-based file storage. Please ensure cdn.base_url config or PN_ACT_CONFIG_CDN_BASE env variable is set to point to this server with the domain being one of ${(0, logger_1.formatHostnames)(exports.config.domains.local_cdn)}`);
        if (exports.disabledFeatures.redis) {
            (0, logger_1.LOG_WARN)('Both S3 and Redis are disabled. Large CDN files will use the in-memory cache, which may result in high memory use. Please enable S3 if you\'re running a production server.');
        }
    }
}
if (!exports.config.aes_key) {
    (0, logger_1.LOG_ERROR)('Token AES key is not set. Set the PN_ACT_CONFIG_AES_KEY environment variable to your AES-256-CBC key');
    configValid = false;
}
if (!exports.config.grpc.master_api_keys.account) {
    (0, logger_1.LOG_ERROR)('Master gRPC API key for the account service is not set. Set the PN_ACT_CONFIG_GRPC_MASTER_API_KEY_ACCOUNT environment variable');
    configValid = false;
}
if (!exports.config.grpc.master_api_keys.api) {
    (0, logger_1.LOG_ERROR)('Master gRPC API key for the api service is not set. Set the PN_ACT_CONFIG_GRPC_MASTER_API_KEY_API environment variable');
    configValid = false;
}
if (!exports.config.grpc.port) {
    (0, logger_1.LOG_ERROR)('Failed to find gRPC port. Set the PN_ACT_CONFIG_GRPC_PORT environment variable');
    configValid = false;
}
if (!exports.config.stripe?.secret_key) {
    (0, logger_1.LOG_WARN)('Failed to find Stripe api key! If a PNID is deleted with an active subscription, the subscription will *NOT* be canceled! Set the PN_ACT_CONFIG_STRIPE_SECRET_KEY environment variable to enable');
}
if (!exports.config.datastore.signature_secret) {
    (0, logger_1.LOG_WARN)('Datastore signature secret key is not set. Disabling feature. To enable feature set the PN_ACT_CONFIG_DATASTORE_SIGNATURE_SECRET environment variable');
    exports.disabledFeatures.datastore = true;
}
else {
    if (exports.config.datastore.signature_secret.length !== 32 || !hexadecimalStringRegex.test(exports.config.datastore.signature_secret)) {
        (0, logger_1.LOG_ERROR)('Datastore signature secret key must be a 32-character hexadecimal string.');
        configValid = false;
    }
}
if (!configValid) {
    (0, logger_1.LOG_ERROR)('Config is invalid. Exiting');
    process.exit(0);
}
