"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ACCESS_LEVEL;
(function (ACCESS_LEVEL) {
    ACCESS_LEVEL[ACCESS_LEVEL["User"] = 0] = "User";
    ACCESS_LEVEL[ACCESS_LEVEL["Admin"] = 1] = "Admin";
    ACCESS_LEVEL[ACCESS_LEVEL["Owner"] = 2] = "Owner";
    ACCESS_LEVEL[ACCESS_LEVEL["Dev"] = 3] = "Dev";
})(ACCESS_LEVEL || (ACCESS_LEVEL = {}));
