"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.optionalDomainServices = exports.domainServices = void 0;
exports.domainServices = ['api', 'assets', 'cbvc', 'conntest', 'datastore', 'nasc', 'nnas', 'local_cdn'];
exports.optionalDomainServices = ['local_cdn'];
