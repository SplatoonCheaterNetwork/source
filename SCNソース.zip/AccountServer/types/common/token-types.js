"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TokenType = void 0;
// TODO - Maybe this shouldn't be in the `types` folder, since it's also actual data?
var TokenType;
(function (TokenType) {
    TokenType[TokenType["OAuthAccess"] = 1] = "OAuthAccess";
    TokenType[TokenType["OAuthRefresh"] = 2] = "OAuthRefresh";
    TokenType[TokenType["NEX"] = 3] = "NEX";
    TokenType[TokenType["IndependentService"] = 4] = "IndependentService";
    TokenType[TokenType["PasswordReset"] = 5] = "PasswordReset";
})(TokenType = exports.TokenType || (exports.TokenType = {}));
