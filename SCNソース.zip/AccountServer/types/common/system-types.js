"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemType = void 0;
// TODO - Maybe this shouldn't be in the `types` folder, since it's also actual data?
// * WUP and CTR are wrong officially, these are just the IDs we gave.
// * Normally CTR comes before WUP, but we supported WUP before CTR
var SystemType;
(function (SystemType) {
    SystemType[SystemType["WUP"] = 1] = "WUP";
    SystemType[SystemType["CTR"] = 2] = "CTR";
    SystemType[SystemType["API"] = 3] = "API";
    SystemType[SystemType["PasswordReset"] = 255] = "PasswordReset"; // * This kinda blows
})(SystemType = exports.SystemType || (exports.SystemType = {}));
