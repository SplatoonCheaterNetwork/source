"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatHostnames = exports.LOG_INFO = exports.LOG_WARN = exports.LOG_ERROR = exports.LOG_SUCCESS = void 0;
const fs_extra_1 = __importDefault(require("fs-extra"));
const colors_1 = __importDefault(require("colors"));
colors_1.default.enable();
const root = process.env.PN_ACT_LOGGER_PATH ? process.env.PN_ACT_LOGGER_PATH : `${__dirname}/..`;
fs_extra_1.default.ensureDirSync(`${root}/logs`);
const streams = {
    latest: fs_extra_1.default.createWriteStream(`${root}/logs/latest.log`),
    success: fs_extra_1.default.createWriteStream(`${root}/logs/success.log`),
    error: fs_extra_1.default.createWriteStream(`${root}/logs/error.log`),
    warn: fs_extra_1.default.createWriteStream(`${root}/logs/warn.log`),
    info: fs_extra_1.default.createWriteStream(`${root}/logs/info.log`)
};
function getTimeStamp() {
    const time = new Date();
    const hours = String(time.getHours()).padStart(2, '0');
    const minutes = String(time.getMinutes()).padStart(2, '0');
    const seconds = String(time.getSeconds()).padStart(2, '0');
    return `[${hours}:${minutes}:${seconds}]`;
}
function LOG_SUCCESS(input) {
    input = `[${getTimeStamp()}] [SUCCESS]: ${input}`;
    streams.success.write(`${input}\n`);
    console.log(`${input}`.green.bold);
}
exports.LOG_SUCCESS = LOG_SUCCESS;
function LOG_ERROR(input) {
    input = `[${getTimeStamp()}] [ERROR]: ${input}`;
    streams.error.write(`${input}\n`);
    console.log(`${input}`.red.bold);
}
exports.LOG_ERROR = LOG_ERROR;
function LOG_WARN(input) {
    input = `[${getTimeStamp()}] [WARN]: ${input}`;
    streams.warn.write(`${input}\n`);
    console.log(`${input}`.yellow.bold);
}
exports.LOG_WARN = LOG_WARN;
function LOG_INFO(input) {
    input = `[${getTimeStamp()}] [INFO]: ${input}`;
    streams.info.write(`${input}\n`);
    console.log(`${input}`.cyan.bold);
}
exports.LOG_INFO = LOG_INFO;
function formatHostnames(hostnames) {
    return hostnames.map(d => `'${d}'`).join(', ');
}
exports.formatHostnames = formatHostnames;
